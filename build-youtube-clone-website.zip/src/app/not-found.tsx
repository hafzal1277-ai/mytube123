import Link from "next/link";
import Logo from "@/components/Logo";

export default function NotFound() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-yt-bg px-6 text-center">
      <Logo />
      <p className="mt-10 text-[80px] font-bold leading-none text-yt-chip">
        404
      </p>
      <h1 className="mt-4 text-xl font-medium text-yt-text">
        Yeh page mojood nahi hai
      </h1>
      <p className="mt-2 max-w-sm text-sm text-yt-sub">
        Ho sakta hai video delete ho gaya ho ya link ghalat ho. Home par wapas
        chalein.
      </p>
      <Link
        href="/"
        className="mt-8 flex h-10 items-center rounded-full bg-white px-6 text-sm font-medium text-black transition-transform hover:scale-[1.03]"
      >
        Go to home
      </Link>
    </div>
  );
}
