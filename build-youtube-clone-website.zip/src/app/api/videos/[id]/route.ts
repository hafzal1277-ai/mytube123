import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { videos } from "@/db/schema";
import { getViewer } from "@/lib/viewer";
import { safeUnlink } from "@/lib/uploads";
import { CATEGORIES } from "@/lib/constants";
import { ensureAppReady } from "@/lib/bootstrap";

export const runtime = "nodejs";

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function canManage(viewer: Awaited<ReturnType<typeof getViewer>>, video: { uploaderId: string | null }) {
  return Boolean(viewer && (viewer.isAdmin || (viewer.id && viewer.id === video.uploaderId)));
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await ensureAppReady();
  const viewer = await getViewer();
  if (!viewer) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await params;
  if (!UUID_RE.test(id)) return NextResponse.json({ error: "Invalid id" }, { status: 400 });

  const [row] = await db.select().from(videos).where(eq(videos.id, id)).limit(1);
  if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (!canManage(viewer, row)) {
    return NextResponse.json({ error: "You can only delete your own videos" }, { status: 403 });
  }

  await db.delete(videos).where(eq(videos.id, id));
  safeUnlink(row.videoPath);
  safeUnlink(row.thumbnailPath);
  return NextResponse.json({ ok: true });
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await ensureAppReady();
  const viewer = await getViewer();
  if (!viewer) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await params;
  if (!UUID_RE.test(id)) return NextResponse.json({ error: "Invalid id" }, { status: 400 });

  const [existing] = await db.select().from(videos).where(eq(videos.id, id)).limit(1);
  if (!existing) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (!canManage(viewer, existing)) {
    return NextResponse.json({ error: "You can only edit your own videos" }, { status: 403 });
  }

  let body: { title?: string; description?: string; category?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  }

  const title = (body.title || "").trim().slice(0, 150);
  if (!title) return NextResponse.json({ error: "Title zaroori hai" }, { status: 400 });

  const description = (body.description || "").trim().slice(0, 5000);
  const category = (CATEGORIES as readonly string[]).includes(body.category || "")
    ? (body.category as string)
    : "General";

  const [row] = await db
    .update(videos)
    .set({ title, description, category })
    .where(eq(videos.id, id))
    .returning();

  return NextResponse.json({ ok: true, video: row });
}
