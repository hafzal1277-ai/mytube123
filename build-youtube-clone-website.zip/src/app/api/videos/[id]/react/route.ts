import { NextRequest, NextResponse } from "next/server";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { videos } from "@/db/schema";
import { ensureAppReady } from "@/lib/bootstrap";

export const runtime = "nodejs";

const UUID_RE =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

type Reaction = "like" | "dislike" | null;

function normalize(v: unknown): Reaction {
  return v === "like" || v === "dislike" ? v : null;
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await ensureAppReady();
  const { id } = await params;
  if (!UUID_RE.test(id)) {
    return NextResponse.json({ error: "Invalid id" }, { status: 400 });
  }

  let body: { next?: unknown; prev?: unknown };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  }

  const next = normalize(body.next);
  const prev = normalize(body.prev);

  const dLikes = (next === "like" ? 1 : 0) - (prev === "like" ? 1 : 0);
  const dDislikes =
    (next === "dislike" ? 1 : 0) - (prev === "dislike" ? 1 : 0);

  const [row] = await db
    .update(videos)
    .set({
      likes: sql`greatest(0, ${videos.likes} + ${dLikes})`,
      dislikes: sql`greatest(0, ${videos.dislikes} + ${dDislikes})`,
    })
    .where(eq(videos.id, id))
    .returning({ likes: videos.likes, dislikes: videos.dislikes });

  if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json({ ok: true, ...row });
}
