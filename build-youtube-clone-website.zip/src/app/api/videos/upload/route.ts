import { NextRequest, NextResponse } from "next/server";
import { Readable } from "stream";
import fs from "fs";
import { randomUUID } from "crypto";
import busboy from "busboy";
import { db } from "@/db";
import { videos } from "@/db/schema";
import { getViewer } from "@/lib/viewer";
import {
  ensureUploadDirs,
  videoExt,
  imageExt,
  isVideoMime,
  isImageMime,
  publicPathToDisk,
  safeUnlink,
} from "@/lib/uploads";
import { CATEGORIES } from "@/lib/constants";
import { ensureAppReady } from "@/lib/bootstrap";

export const runtime = "nodejs";
export const maxDuration = 600;

export async function POST(req: NextRequest) {
  await ensureAppReady();
  const viewer = await getViewer();
  if (!viewer) {
    return NextResponse.json({ error: "Sign in required" }, { status: 401 });
  }

  const contentType = req.headers.get("content-type") || "";
  if (!contentType.toLowerCase().includes("multipart/form-data")) {
    return NextResponse.json({ error: "Expected multipart/form-data" }, { status: 400 });
  }
  if (!req.body) {
    return NextResponse.json({ error: "Empty request body" }, { status: 400 });
  }

  ensureUploadDirs();

  const id = randomUUID();
  const fields: Record<string, string> = {};
  let videoRel: string | null = null;
  let thumbRel: string | null = null;
  let videoBytes = 0;
  let thumbBytes = 0;
  let limitHit = false;
  const pendingWrites: Promise<void>[] = [];

  const bb = busboy({
    headers: { "content-type": contentType },
    limits: { fileSize: 1024 * 1024 * 1024 * 4, files: 2, fields: 20 },
  });

  bb.on("field", (name, val) => {
    fields[name] = val;
  });

  bb.on("file", (name, stream, info) => {
    const filename = info.filename || "";
    const mime = info.mimeType || "";

    stream.on("limit", () => {
      limitHit = true;
    });

    const save = (rel: string, counter: (n: number) => void) => {
      const disk = publicPathToDisk(rel);
      const ws = fs.createWriteStream(disk);
      stream.on("data", (c: Buffer) => counter(c.length));
      stream.pipe(ws);
      pendingWrites.push(
        new Promise<void>((resolve, reject) => {
          ws.on("finish", () => resolve());
          ws.on("error", reject);
        })
      );
    };

    if (name === "video" && filename && isVideoMime(mime)) {
      videoRel = `/api/media/videos/${id}${videoExt(mime, filename)}`;
      save(videoRel, (n) => (videoBytes += n));
    } else if (name === "thumbnail" && filename && isImageMime(mime)) {
      thumbRel = `/api/media/thumbnails/${id}${imageExt(mime, filename)}`;
      save(thumbRel, (n) => (thumbBytes += n));
    } else {
      stream.resume();
    }
  });

  try {
    await new Promise<void>((resolve, reject) => {
      bb.on("close", () => resolve());
      bb.on("error", reject);
      const nodeStream = Readable.fromWeb(req.body as unknown as import("stream/web").ReadableStream);
      nodeStream.on("error", reject);
      nodeStream.pipe(bb);
    });
    await Promise.all(pendingWrites);
  } catch (e) {
    console.error("Upload parse error:", e);
    safeUnlink(videoRel);
    safeUnlink(thumbRel);
    return NextResponse.json({ error: "Upload failed" }, { status: 500 });
  }

  if (limitHit) {
    safeUnlink(videoRel);
    safeUnlink(thumbRel);
    return NextResponse.json({ error: "File too large (max 4GB)" }, { status: 413 });
  }

  if (!videoRel || videoBytes === 0) {
    safeUnlink(videoRel);
    safeUnlink(thumbRel);
    return NextResponse.json({ error: "Video file zaroori hai" }, { status: 400 });
  }

  const title = (fields.title || "").trim().slice(0, 150);
  if (!title) {
    safeUnlink(videoRel);
    safeUnlink(thumbRel);
    return NextResponse.json({ error: "Video title zaroori hai" }, { status: 400 });
  }

  if (!thumbRel || thumbBytes === 0) {
    if (thumbRel) safeUnlink(thumbRel);
    thumbRel = null;
  }

  const description = (fields.description || "").trim().slice(0, 5000);
  const category = (CATEGORIES as readonly string[]).includes(fields.category)
    ? fields.category
    : "General";
  const durationSeconds = Math.max(0, Math.round(Number(fields.durationSeconds) || 0));
  const adEnabled = fields.adEnabled === "1";
  const adTitle = (fields.adTitle || "Sponsored").trim().slice(0, 120) || "Sponsored";
  const adClickUrl = (fields.adClickUrl || "").trim().slice(0, 1000);
  const adHtml = (fields.adHtml || "").trim().slice(0, 40000);
  const adSkipAfterSeconds = Math.min(
    15,
    Math.max(1, Math.round(Number(fields.adSkipAfterSeconds) || 5))
  );

  if (adEnabled && !adHtml && !adClickUrl) {
    safeUnlink(videoRel);
    safeUnlink(thumbRel);
    return NextResponse.json(
      { error: "Ad enable karne ke liye HTML code ya link zaroori hai" },
      { status: 400 }
    );
  }

  try {
    const [row] = await db
      .insert(videos)
      .values({
        id,
        uploaderId: viewer.isAdmin ? null : viewer.id,
        uploaderName: viewer.name,
        uploaderImage: viewer.image,
        title,
        description,
        category,
        videoPath: videoRel,
        thumbnailPath: thumbRel,
        adTitle,
        adHtml: adEnabled ? adHtml || null : null,
        adClickUrl: adEnabled ? adClickUrl || null : null,
        adSkipAfterSeconds,
        durationSeconds,
      })
      .returning();
    return NextResponse.json({ ok: true, video: row });
  } catch (e) {
    console.error("Upload DB error:", e);
    safeUnlink(videoRel);
    safeUnlink(thumbRel);
    return NextResponse.json({ error: "Upload failed" }, { status: 500 });
  }
}
