import { NextRequest, NextResponse } from "next/server";
import { headers } from "next/headers";
import {
  verifyAdminCredentials,
  signAdminSession,
  sessionCookieOptions,
} from "@/lib/auth";

export const runtime = "nodejs";

/** Build an absolute URL that works behind proxies */
async function absUrl(path: string, req: NextRequest): Promise<string> {
  const h = await headers();
  const host =
    h.get("x-forwarded-host") || h.get("host") || req.nextUrl.host;
  // Always use https — preview proxy terminates TLS
  const proto = host.includes("localhost") || host.startsWith("127.") ? "http" : "https";
  return `${proto}://${host}${path}`;
}

export async function POST(req: NextRequest) {
  const contentType = req.headers.get("content-type") || "";

  // ── HTML form submission (application/x-www-form-urlencoded) ──
  if (contentType.includes("form-urlencoded")) {
    const fd = await req.formData();
    const username = ((fd.get("username") as string) || "").trim();
    const password = (fd.get("password") as string) || "";

    if (!username || !password) {
      const url = await absUrl("/admin/owner-secret?error=missing", req);
      return NextResponse.redirect(url, 303);
    }

    try {
      const ok = await verifyAdminCredentials(username, password);
      if (!ok) {
        const url = await absUrl("/admin/owner-secret?error=invalid", req);
        return NextResponse.redirect(url, 303);
      }
      const token = await signAdminSession(username);
      const url = await absUrl("/admin", req);
      const res = NextResponse.redirect(url, 303);
      res.cookies.set({ ...sessionCookieOptions(), value: token });
      return res;
    } catch (e) {
      console.error("Login error:", e);
      const url = await absUrl("/admin/login?error=server", req);
      return NextResponse.redirect(url, 303);
    }
  }

  // ── JSON login (fetch from client JS) ──
  let body: { username?: string; password?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  }

  const username = (body.username || "").trim();
  const password = body.password || "";

  if (!username || !password) {
    return NextResponse.json(
      { error: "Username aur password dono zaroori hain" },
      { status: 400 }
    );
  }

  try {
    const ok = await verifyAdminCredentials(username, password);
    if (!ok) {
      return NextResponse.json(
        { error: "Invalid username or password" },
        { status: 401 }
      );
    }
    const token = await signAdminSession(username);
    const res = NextResponse.json({ ok: true, username });
    res.cookies.set({ ...sessionCookieOptions(), value: token });
    return res;
  } catch (e) {
    console.error("Login error:", e);
    return NextResponse.json(
      { error: "Login mein masla hua, dobara koshish karein" },
      { status: 500 }
    );
  }
}
