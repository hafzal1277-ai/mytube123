import { NextRequest, NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { comments, videos } from "@/db/schema";
import { ensureAppReady } from "@/lib/bootstrap";

export const runtime = "nodejs";

const UUID_RE =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export async function GET(req: NextRequest) {
  await ensureAppReady();
  const videoId = req.nextUrl.searchParams.get("videoId") || "";
  if (!UUID_RE.test(videoId)) {
    return NextResponse.json({ error: "Invalid video id" }, { status: 400 });
  }
  const rows = await db
    .select()
    .from(comments)
    .where(eq(comments.videoId, videoId))
    .orderBy(desc(comments.createdAt))
    .limit(200);
  return NextResponse.json({ comments: rows });
}

export async function POST(req: NextRequest) {
  await ensureAppReady();
  let body: { videoId?: string; author?: string; content?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  }

  const videoId = (body.videoId || "").trim();
  const author = (body.author || "").trim().slice(0, 50) || "Guest";
  const content = (body.content || "").trim().slice(0, 1000);

  if (!UUID_RE.test(videoId)) {
    return NextResponse.json({ error: "Invalid video id" }, { status: 400 });
  }
  if (!content) {
    return NextResponse.json(
      { error: "Comment khali nahi ho sakta" },
      { status: 400 }
    );
  }

  const [video] = await db
    .select({ id: videos.id })
    .from(videos)
    .where(eq(videos.id, videoId))
    .limit(1);
  if (!video) {
    return NextResponse.json({ error: "Video not found" }, { status: 404 });
  }

  const [row] = await db
    .insert(comments)
    .values({ videoId, author, content })
    .returning();
  return NextResponse.json({ ok: true, comment: row });
}
