import { NextRequest, NextResponse } from "next/server";
import { Readable } from "stream";
import fs from "fs";
import path from "path";
import { stat } from "fs/promises";

export const runtime = "nodejs";

const UPLOADS = path.join(process.cwd(), "public", "uploads");

const MIME: Record<string, string> = {
  ".mp4": "video/mp4",
  ".webm": "video/webm",
  ".ogv": "video/ogg",
  ".mov": "video/quicktime",
  ".mkv": "video/x-matroska",
  ".avi": "video/x-msvideo",
  ".3gp": "video/3gpp",
  ".mpeg": "video/mpeg",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".webp": "image/webp",
  ".gif": "image/gif",
  ".avif": "image/avif",
  ".svg": "image/svg+xml",
};

function toWeb(stream: fs.ReadStream): ReadableStream {
  return Readable.toWeb(stream) as unknown as ReadableStream;
}

type Ctx = { params: Promise<{ path: string[] }> };

async function resolveFile(segments: string[] | undefined) {
  if (!segments || segments.length === 0) return null;
  const clean: string[] = [];
  for (const s of segments) {
    const dec = decodeURIComponent(s);
    if (!dec || dec === "." || dec === ".." || dec.includes("\0")) return null;
    clean.push(dec);
  }
  const filePath = path.join(UPLOADS, ...clean);
  if (!filePath.startsWith(UPLOADS + path.sep)) return null;
  return filePath;
}

export async function GET(req: NextRequest, ctx: Ctx) {
  const { path: segments } = await ctx.params;
  const filePath = await resolveFile(segments);
  if (!filePath) return new NextResponse("Not found", { status: 404 });

  let st: fs.Stats;
  try {
    st = await stat(filePath);
  } catch {
    return new NextResponse("Not found", { status: 404 });
  }
  if (!st.isFile()) return new NextResponse("Not found", { status: 404 });

  const size = st.size;
  const type =
    MIME[path.extname(filePath).toLowerCase()] || "application/octet-stream";
  const baseHeaders: Record<string, string> = {
    "Content-Type": type,
    "Accept-Ranges": "bytes",
    "Cache-Control": "public, max-age=3600",
  };

  const range = req.headers.get("range");
  if (range) {
    const m = /^bytes=(\d*)-(\d*)$/.exec(range.trim());
    if (m) {
      let start = m[1] ? parseInt(m[1], 10) : NaN;
      let end = m[2] ? parseInt(m[2], 10) : NaN;
      if (Number.isNaN(start) && !Number.isNaN(end)) {
        start = Math.max(0, size - end);
        end = size - 1;
      } else if (!Number.isNaN(start)) {
        end = Number.isNaN(end) ? size - 1 : Math.min(end, size - 1);
      }
      if (Number.isNaN(start) || Number.isNaN(end) || start >= size || start > end) {
        return new NextResponse(null, {
          status: 416,
          headers: { "Content-Range": `bytes */${size}` },
        });
      }
      const chunkSize = end - start + 1;
      const stream = fs.createReadStream(filePath, { start, end });
      return new NextResponse(toWeb(stream), {
        status: 206,
        headers: {
          ...baseHeaders,
          "Content-Length": String(chunkSize),
          "Content-Range": `bytes ${start}-${end}/${size}`,
        },
      });
    }
  }

  const stream = fs.createReadStream(filePath);
  return new NextResponse(toWeb(stream), {
    status: 200,
    headers: { ...baseHeaders, "Content-Length": String(size) },
  });
}

export async function HEAD(_req: NextRequest, ctx: Ctx) {
  const { path: segments } = await ctx.params;
  const filePath = await resolveFile(segments);
  if (!filePath) return new NextResponse(null, { status: 404 });
  try {
    const st = await stat(filePath);
    if (!st.isFile()) return new NextResponse(null, { status: 404 });
    const type =
      MIME[path.extname(filePath).toLowerCase()] || "application/octet-stream";
    return new NextResponse(null, {
      status: 200,
      headers: {
        "Content-Type": type,
        "Content-Length": String(st.size),
        "Accept-Ranges": "bytes",
      },
    });
  } catch {
    return new NextResponse(null, { status: 404 });
  }
}
