import AppShell from "@/components/AppShell";
import { getViewer } from "@/lib/viewer";

export default async function SiteLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const viewer = await getViewer();
  return <AppShell viewer={viewer}>{children}</AppShell>;
}
