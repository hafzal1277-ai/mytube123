import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { desc, eq, ne, sql } from "drizzle-orm";
import { db } from "@/db";
import { comments, videos } from "@/db/schema";
import WatchClient from "@/components/WatchClient";
import { VideoRowCard, type CardVideo } from "@/components/VideoCard";
import { formatDate, formatDuration, formatViews, timeAgo } from "@/lib/format";
import { DEFAULT_CHANNEL_NAME } from "@/lib/constants";
import { getViewer } from "@/lib/viewer";
import { buildVideoPreRoll, getPreRollConfig } from "@/lib/ads";
import { ensureAppReady } from "@/lib/bootstrap";

export const dynamic = "force-dynamic";

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

type SP = Promise<Record<string, string | string[] | undefined>>;

export async function generateMetadata({ searchParams }: { searchParams: SP }): Promise<Metadata> {
  const sp = await searchParams;
  const id = typeof sp.v === "string" ? sp.v : "";
  if (!UUID_RE.test(id)) return { title: "Watch" };
  const [video] = await db
    .select({ title: videos.title })
    .from(videos)
    .where(eq(videos.id, id))
    .limit(1);
  return { title: video ? video.title : "Watch" };
}

export default async function WatchPage({ searchParams }: { searchParams: SP }) {
  await ensureAppReady();
  const sp = await searchParams;
  const id = typeof sp.v === "string" ? sp.v : "";
  if (!UUID_RE.test(id)) notFound();

  const [video] = await db.select().from(videos).where(eq(videos.id, id)).limit(1);
  if (!video) notFound();

  const [relatedRows, commentRows, viewer] = await Promise.all([
    db
      .select()
      .from(videos)
      .where(ne(videos.id, id))
      .orderBy(
        sql`case when ${videos.category} = ${video.category} then 0 else 1 end`,
        desc(videos.createdAt)
      )
      .limit(12),
    db
      .select()
      .from(comments)
      .where(eq(comments.videoId, id))
      .orderBy(desc(comments.createdAt))
      .limit(100),
    getViewer(),
  ]);

  const canManage = Boolean(viewer && (viewer.isAdmin || (viewer.id && viewer.id === video.uploaderId)));
  const adConfig =
    buildVideoPreRoll({
      adTitle: video.adTitle,
      adHtml: video.adHtml,
      adClickUrl: video.adClickUrl,
      adSkipAfterSeconds: video.adSkipAfterSeconds,
    }) || getPreRollConfig();

  const related: CardVideo[] = relatedRows.map((v) => ({
    id: v.id,
    title: v.title,
    thumbnail: v.thumbnailPath,
    durationLabel: formatDuration(v.durationSeconds),
    metaLine: `${formatViews(v.views)} views • ${timeAgo(v.createdAt)}`,
    channelName: v.uploaderName || DEFAULT_CHANNEL_NAME,
    channelImage: v.uploaderImage,
  }));

  return (
    <div className="mx-auto max-w-[1754px] animate-fade-up pb-16 sm:px-4 xl:px-6">
      <div className="grid grid-cols-1 gap-8 pt-0 sm:pt-6 xl:grid-cols-[minmax(0,1fr)_402px]">
        <div className="min-w-0">
          <WatchClient
            video={{
              id: video.id,
              title: video.title,
              src: video.videoPath,
              poster: video.thumbnailPath,
              views: video.views,
              likes: video.likes,
              dislikes: video.dislikes,
              category: video.category,
              description: video.description,
              dateLabel: formatDate(video.createdAt),
              channelName: video.uploaderName || DEFAULT_CHANNEL_NAME,
              channelImage: video.uploaderImage,
            }}
            initialComments={commentRows.map((c) => ({
              id: c.id,
              author: c.author,
              content: c.content,
              when: timeAgo(c.createdAt),
            }))}
            canManage={canManage}
            ad={adConfig}
          />
        </div>

        <aside className="min-w-0 px-4 sm:px-0">
          <div className="no-scrollbar sticky top-14 z-20 -mx-1 flex gap-2 overflow-x-auto bg-[#0f0f0f]/95 px-1 py-2 backdrop-blur">
            <span className="flex h-8 shrink-0 items-center rounded-lg bg-white px-3 text-sm font-medium text-black">
              All
            </span>
            <Link
              href={`/?category=${encodeURIComponent(video.category)}`}
              className="flex h-8 shrink-0 items-center rounded-lg bg-[#272727] px-3 text-sm font-medium text-yt-text transition-colors hover:bg-yt-chip-hover"
            >
              #{video.category}
            </Link>
            <Link
              href="/?sort=popular"
              className="flex h-8 shrink-0 items-center rounded-lg bg-[#272727] px-3 text-sm font-medium text-yt-text transition-colors hover:bg-yt-chip-hover"
            >
              Trending
            </Link>
          </div>

          <div className="mt-2 flex flex-col gap-3">
            {related.length === 0 && (
              <div className="rounded-xl border border-dashed border-yt-chip p-8 text-center text-sm text-yt-sub">
                Abhi aur videos nahi hain. Jald aur aa rahi hain!
              </div>
            )}
            {related.map((v) => (
              <VideoRowCard key={v.id} video={v} />
            ))}
          </div>
        </aside>
      </div>
    </div>
  );
}
