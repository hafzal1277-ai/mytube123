export default function Loading() {
  return (
    <div>
      <div className="no-scrollbar sticky top-14 z-30 flex gap-2 overflow-x-hidden bg-[#0f0f0f]/95 px-4 py-3 backdrop-blur sm:px-6">
        {Array.from({ length: 7 }).map((_, i) => (
          <div key={i} className="skeleton h-8 w-20 shrink-0 rounded-lg" />
        ))}
      </div>
      <div className="grid grid-cols-1 gap-x-4 gap-y-9 px-4 pt-2 sm:grid-cols-2 sm:px-6 lg:grid-cols-3 2xl:grid-cols-4">
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i} className="flex flex-col gap-3">
            <div className="skeleton aspect-video w-full rounded-xl" />
            <div className="flex gap-3">
              <div className="skeleton h-9 w-9 shrink-0 rounded-full" />
              <div className="flex w-full flex-col gap-2 pt-1">
                <div className="skeleton h-4 w-[92%] rounded" />
                <div className="skeleton h-4 w-[60%] rounded" />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
