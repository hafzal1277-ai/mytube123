import Link from "next/link";
import { and, desc, eq, ilike, or } from "drizzle-orm";
import { SearchX, Upload, VideoOff } from "lucide-react";
import { db } from "@/db";
import { videos } from "@/db/schema";
import VideoCard, { type CardVideo } from "@/components/VideoCard";
import { formatDuration, formatViews, timeAgo } from "@/lib/format";
import { CATEGORIES, DEFAULT_CHANNEL_NAME } from "@/lib/constants";
import { getViewer } from "@/lib/viewer";
import { ensureAppReady } from "@/lib/bootstrap";

export const dynamic = "force-dynamic";

type SP = Promise<Record<string, string | string[] | undefined>>;

export default async function HomePage({ searchParams }: { searchParams: SP }) {
  await ensureAppReady();
  const sp = await searchParams;
  const q = typeof sp.q === "string" ? sp.q.trim() : "";
  const category = typeof sp.category === "string" ? sp.category : "";
  const sort = typeof sp.sort === "string" ? sp.sort : "";

  const conds = [];
  if (category && category !== "All") conds.push(eq(videos.category, category));
  if (q) {
    const like = `%${q.replace(/[%_]/g, "")}%`;
    const c = or(ilike(videos.title, like), ilike(videos.description, like));
    if (c) conds.push(c);
  }

  const order =
    sort === "popular"
      ? [desc(videos.views), desc(videos.likes), desc(videos.createdAt)]
      : [desc(videos.createdAt)];

  const [rows, catRows, viewer] = await Promise.all([
    db
      .select()
      .from(videos)
      .where(conds.length ? and(...conds) : undefined)
      .orderBy(...order)
      .limit(60),
    db.selectDistinct({ c: videos.category }).from(videos),
    getViewer(),
  ]);

  const present = new Set(catRows.map((r) => r.c));
  const chips: string[] = [
    "All",
    ...CATEGORIES.filter((c) => present.has(c)),
    ...[...present].filter((c) => !(CATEGORIES as readonly string[]).includes(c)),
  ];

  const cards: CardVideo[] = rows.map((v) => ({
    id: v.id,
    title: v.title,
    thumbnail: v.thumbnailPath,
    durationLabel: formatDuration(v.durationSeconds),
    metaLine: `${formatViews(v.views)} views • ${timeAgo(v.createdAt)}`,
    channelName: v.uploaderName || DEFAULT_CHANNEL_NAME,
    channelImage: v.uploaderImage,
  }));

  const activeChip = category || "All";

  return (
    <div className="animate-fade-up">
      {rows.length > 0 && !q && (
        <div className="no-scrollbar sticky top-14 z-30 flex gap-2 overflow-x-auto bg-[#0f0f0f]/95 px-4 py-3 backdrop-blur sm:px-6">
          {chips.map((c) => {
            const isActive = activeChip === c;
            const href = c === "All" ? "/" : `/?category=${encodeURIComponent(c)}`;
            return (
              <Link
                key={c}
                href={href}
                className={`flex h-8 shrink-0 items-center rounded-lg px-3 text-sm font-medium transition-colors ${
                  isActive
                    ? "bg-white text-black"
                    : "bg-[#272727] text-yt-text hover:bg-yt-chip-hover"
                }`}
              >
                {c}
              </Link>
            );
          })}
        </div>
      )}

      <div className="px-4 pb-16 pt-2 sm:px-6">
        {q && (
          <p className="mb-5 mt-2 text-sm text-yt-sub">
            {rows.length} result{rows.length === 1 ? "" : "s"} for{" "}
            <span className="font-medium text-yt-text">&ldquo;{q}&rdquo;</span>
          </p>
        )}
        {sort === "popular" && !q && rows.length > 0 && (
          <p className="mb-5 mt-2 text-sm text-yt-sub">
            Trending videos — sorted by most viewed
          </p>
        )}

        {cards.length > 0 ? (
          <div className="grid grid-cols-1 gap-x-4 gap-y-9 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4">
            {cards.map((v) => (
              <VideoCard key={v.id} video={v} />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-24 text-center">
            {q ? (
              <>
                <span className="flex h-20 w-20 items-center justify-center rounded-full bg-yt-chip">
                  <SearchX className="h-9 w-9 text-yt-sub" />
                </span>
                <h2 className="mt-6 text-xl font-medium text-yt-text">Koi video nahi mila</h2>
                <p className="mt-2 max-w-sm text-sm text-yt-sub">
                  &ldquo;{q}&rdquo; ke liye koi result nahi. Doosre keywords try karein ya saari videos dekhein.
                </p>
                <Link
                  href="/"
                  className="mt-6 flex h-9 items-center rounded-full bg-white px-5 text-sm font-medium text-black transition-transform hover:scale-[1.03]"
                >
                  Back to home
                </Link>
              </>
            ) : (
              <>
                <span className="flex h-20 w-20 items-center justify-center rounded-full bg-yt-chip">
                  <VideoOff className="h-9 w-9 text-yt-sub" />
                </span>
                <h2 className="mt-6 text-xl font-medium text-yt-text">Abhi yahan koi video nahi hai</h2>
                <p className="mt-2 max-w-sm text-sm text-yt-sub">
                  {viewer
                    ? "Aap sign in hain — apni pehli public video upload karke channel start karein."
                    : "Public videos yahan nazar ayengi. Creator Google/Gmail se sign in karke upload kar sakte hain."}
                </p>
                {viewer && (
                  <Link
                    href="/admin/upload"
                    className="mt-6 flex h-10 items-center gap-2 rounded-full bg-white px-5 text-sm font-medium text-black transition-transform hover:scale-[1.03]"
                  >
                    <Upload className="h-4 w-4" />
                    Upload first video
                  </Link>
                )}
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
