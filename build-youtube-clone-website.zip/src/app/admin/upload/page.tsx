import { redirect } from "next/navigation";
import UploadForm from "@/components/UploadForm";
import { getViewer, isGoogleConfigured } from "@/lib/viewer";
import { ensureAppReady } from "@/lib/bootstrap";

export const dynamic = "force-dynamic";
export const metadata = { title: "Upload video" };

export default async function AdminUploadPage() {
  await ensureAppReady();
  const viewer = await getViewer();
  if (!viewer) redirect("/admin/login");

  return (
    <main className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      <div className="mb-8 flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-yt-text">Upload video</h1>
          <p className="mt-1 text-sm text-yt-sub">
            Video select karein — thumbnail automatically capture ho jayegi, phir publish karein
          </p>
        </div>
        <div className="rounded-2xl border border-yt-border bg-[#141414] px-4 py-3 text-sm text-yt-sub">
          Signed in as <span className="font-medium text-yt-text">{viewer.name}</span>
          {!isGoogleConfigured() && !viewer.isAdmin && (
            <p className="mt-1 text-xs text-amber-300">
              Google OAuth owner setup ke baad enable hoga.
            </p>
          )}
        </div>
      </div>
      <UploadForm />
    </main>
  );
}
