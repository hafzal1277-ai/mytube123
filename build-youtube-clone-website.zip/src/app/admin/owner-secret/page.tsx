import { redirect } from "next/navigation";
import Link from "next/link";
import Logo from "@/components/Logo";
import { getViewer } from "@/lib/viewer";
import { ensureAppReady } from "@/lib/bootstrap";

type SP = Promise<Record<string, string | string[] | undefined>>;

export const dynamic = "force-dynamic";
export const metadata = { title: "Owner Fallback" };

export default async function OwnerSecretPage({ searchParams }: { searchParams: SP }) {
  await ensureAppReady();
  const viewer = await getViewer();
  if (viewer) redirect("/admin");

  const sp = await searchParams;
  const err = typeof sp.error === "string" ? sp.error : null;

  return (
    <div className="flex min-h-screen flex-col items-center justify-center px-4 bg-black">
      <Logo />
      
      <div className="mt-10 w-full max-w-sm rounded-3xl border border-yt-border bg-[#141414] p-8 shadow-2xl">
        <h2 className="text-xl font-bold text-yt-text">Owner Access</h2>
        <p className="mt-1 text-sm text-yt-sub">Use your credentials to access the studio.</p>

        {err && (
          <div className="mt-5 rounded-lg bg-red-500/10 p-3 text-xs text-red-400 border border-red-500/20">
            Login failed. Please check your credentials.
          </div>
        )}

        <form method="POST" action="/api/auth/login" className="mt-6 flex flex-col gap-4">
          <input
            type="text"
            name="username"
            defaultValue="admin"
            required
            className="h-11 w-full rounded-lg border border-yt-border bg-[#0f0f0f] px-4 text-sm text-yt-text outline-none focus:border-yt-red"
            placeholder="Username"
          />
          <input
            type="password"
            name="password"
            defaultValue="admin123"
            required
            className="h-11 w-full rounded-lg border border-yt-border bg-[#0f0f0f] px-4 text-sm text-yt-text outline-none focus:border-yt-red"
            placeholder="Password"
          />
          <button
            type="submit"
            className="mt-2 h-11 rounded-full bg-yt-red text-sm font-bold text-white transition-all hover:bg-[#e6002e]"
          >
            Sign in as Owner
          </button>
        </form>
      </div>
      
      <Link href="/admin/login" className="mt-6 text-xs text-yt-sub hover:text-yt-text">
        ← Back to Gmail login
      </Link>
    </div>
  );
}
