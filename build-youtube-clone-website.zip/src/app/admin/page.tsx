import Link from "next/link";
import { redirect } from "next/navigation";
import { desc, eq, inArray, sql } from "drizzle-orm";
import { Eye, Film, Heart, MessageSquare, Upload } from "lucide-react";
import { db } from "@/db";
import { comments, videos } from "@/db/schema";
import { getViewer, isGoogleConfigured } from "@/lib/viewer";
import { formatDate, formatDuration, formatViews } from "@/lib/format";
import { ensureAppReady } from "@/lib/bootstrap";
import AdminTable, { type AdminVideoItem } from "@/components/AdminTable";

export const dynamic = "force-dynamic";
export const metadata = { title: "Dashboard" };

export default async function AdminDashboardPage() {
  await ensureAppReady();
  const viewer = await getViewer();
  if (!viewer) redirect("/admin/login");
  if (!viewer.isAdmin && !viewer.id) redirect("/admin/login?error=server");

  const rows = viewer.isAdmin
    ? await db.select().from(videos).orderBy(desc(videos.createdAt)).limit(200)
    : await db
        .select()
        .from(videos)
        .where(eq(videos.uploaderId, viewer.id!))
        .orderBy(desc(videos.createdAt))
        .limit(200);

  const videoIds = rows.map((r) => r.id);
  const commentTotal = videoIds.length
    ? await db
        .select({ count: sql<number>`count(*)::int` })
        .from(comments)
        .where(inArray(comments.videoId, videoIds))
    : [{ count: 0 }];

  const items: AdminVideoItem[] = rows.map((v) => ({
    id: v.id,
    title: v.title,
    description: v.description,
    category: v.category,
    thumbnail: v.thumbnailPath,
    durationLabel: formatDuration(v.durationSeconds),
    viewsLabel: formatViews(v.views),
    views: v.views,
    likes: v.likes,
    dateLabel: formatDate(v.createdAt),
    ownerName: v.uploaderName,
  }));

  const totals = rows.reduce(
    (acc, v) => {
      acc.count += 1;
      acc.views += v.views;
      acc.likes += v.likes;
      return acc;
    },
    { count: 0, views: 0, likes: 0 }
  );

  const statCards = [
    { icon: Film, label: viewer.isAdmin ? "All videos" : "Your videos", value: formatViews(totals.count) },
    { icon: Eye, label: "Total views", value: formatViews(totals.views) },
    { icon: Heart, label: "Total likes", value: formatViews(totals.likes) },
    { icon: MessageSquare, label: "Comments", value: formatViews(commentTotal[0]?.count ?? 0) },
  ];

  return (
    <main className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      <div className="flex flex-wrap items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-yt-text">{viewer.isAdmin ? "Channel content" : "Your creator studio"}</h1>
          <p className="mt-1 text-sm text-yt-sub">
            {viewer.isAdmin
              ? "Owner mode — saari videos manage karein"
              : "Aapki apni uploaded videos yahan manage hongi"}
          </p>
        </div>
        <Link
          href="/admin/upload"
          className="ml-auto flex h-10 items-center gap-2 rounded-full bg-yt-red px-5 text-sm font-bold text-white transition-transform hover:scale-[1.03] hover:bg-[#e6002e]"
        >
          <Upload className="h-4 w-4" />
          Upload video
        </Link>
      </div>

      {!viewer.isAdmin && !isGoogleConfigured() && (
        <div className="mt-6 rounded-2xl border border-amber-500/30 bg-amber-500/10 p-4 text-sm text-amber-200">
          Google/Gmail login ka UI ready hai. Owner ko sirf AUTH_GOOGLE_ID aur AUTH_GOOGLE_SECRET env mein add karne hain.
        </div>
      )}

      <div className="mt-6 rounded-2xl border border-yt-border bg-[#141414] p-4 text-sm text-yt-sub">
        <p className="font-medium text-yt-text">Pre-roll ad monetization ready</p>
        <p className="mt-1 leading-6">
          Viewer jab video play karega to configured pre-roll ad pehle chalegi. Adsterra ya kisi bhi sponsor campaign ke liye .env mein
          <code className="mx-1 rounded bg-black/40 px-1.5 py-0.5">NEXT_PUBLIC_PREROLL_CLICK_URL</code>
          aur optional
          <code className="mx-1 rounded bg-black/40 px-1.5 py-0.5">NEXT_PUBLIC_PREROLL_VIDEO_URL</code>
          / iframe / image values set karein.
        </p>
      </div>

      <div className="mt-8 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {statCards.map((c) => (
          <div key={c.label} className="rounded-2xl border border-yt-border bg-[#141414] p-5 transition-colors hover:border-[#3d3d3d]">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-yt-chip">
              <c.icon className="h-5 w-5 text-yt-text" />
            </span>
            <p className="mt-4 text-2xl font-bold text-yt-text">{c.value}</p>
            <p className="text-sm text-yt-sub">{c.label}</p>
          </div>
        ))}
      </div>

      <div className="mt-10">
        <AdminTable items={items} adminName={viewer.name} />
      </div>
    </main>
  );
}
