import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import Logo from "@/components/Logo";
import StudioLogout from "@/components/StudioLogout";
import { getViewer } from "@/lib/viewer";

export const metadata = {
  title: "MyTube Studio",
};

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const viewer = await getViewer();

  return (
    <div className="min-h-screen bg-[#0b0b0b]">
      <header className="sticky top-0 z-40 flex h-14 items-center gap-3 border-b border-yt-border bg-[#0f0f0f]/95 px-4 backdrop-blur sm:px-6">
        <Link
          href="/"
          title="Back to site"
          className="rounded-full p-2 text-yt-text transition-colors hover:bg-yt-chip"
        >
          <ArrowLeft className="h-5 w-5" />
        </Link>
        <Logo />
        <span className="rounded-md bg-yt-chip px-2 py-0.5 text-[11px] font-bold uppercase tracking-wider text-yt-sub">
          Studio
        </span>
        <div className="ml-auto flex items-center gap-3">
          <Link
            href="/"
            className="hidden text-sm font-medium text-yt-sub transition-colors hover:text-yt-text sm:inline"
          >
            View site
          </Link>
          {viewer && (
            <>
              <span className="hidden text-sm text-yt-sub sm:inline">
                {viewer.name}
              </span>
              <StudioLogout authProvider={viewer.authProvider} />
            </>
          )}
        </div>
      </header>
      {children}
    </div>
  );
}
