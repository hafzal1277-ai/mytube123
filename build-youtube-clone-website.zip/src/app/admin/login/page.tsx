import { redirect } from "next/navigation";
import Link from "next/link";
import { Globe, ShieldCheck, Sparkles, Mail } from "lucide-react";
import Logo from "@/components/Logo";
import { getViewer, isGoogleConfigured } from "@/lib/viewer";
import { signIn } from "@/auth";
import { ensureAppReady } from "@/lib/bootstrap";

type SP = Promise<Record<string, string | string[] | undefined>>;

export const dynamic = "force-dynamic";
export const metadata = { title: "Creator Sign in" };

export default async function AdminLoginPage({ searchParams }: { searchParams: SP }) {
  await ensureAppReady();

  // Handle potential Auth.js crash by safely checking viewer
  let viewer = null;
  try {
    viewer = await getViewer();
  } catch (e) {
    console.error("Viewer fetch error", e);
  }
  
  if (viewer) redirect("/admin");

  let sp: Record<string, string | string[] | undefined> = {};
  try {
    sp = await searchParams;
  } catch {}
  
  const err = typeof sp.error === "string" ? sp.error : null;
  const googleReady = isGoogleConfigured();

  async function googleAction() {
    "use server";
    try {
      await signIn("google", { redirectTo: "/admin" });
    } catch (error) {
      if ((error as Error).message === "NEXT_REDIRECT") {
        throw error;
      }
      redirect("/admin/login?error=OAuthSignin");
    }
  }

  const errorMessage: Record<string, string> = {
    missing: "Data missing — dobara try karein",
    invalid: "Sign in fail hui — details check karein",
    server: "Server error — dobara try karein",
    OAuthSignin: "Google sign-in start nahi hui. Shayad Keys missing hain.",
    OAuthCallback: "Google login callback mein issue aya.",
    AccessDenied: "Google account allow nahi hua.",
  };

  return (
    <div className="flex min-h-[calc(100vh-56px)] flex-col items-center justify-center px-4 py-12">
      <div className="mb-10 scale-125">
        <Logo />
      </div>

      <div className="w-full max-w-md rounded-3xl border border-yt-border bg-[#141414] p-8 shadow-2xl">
        <div className="text-center">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-white/5">
            <Mail className="h-8 w-8 text-white" />
          </div>
          <h1 className="mt-6 text-2xl font-bold text-yt-text">Creator Sign in</h1>
          <p className="mt-2 text-sm text-yt-sub">
            Apni videos upload karne ke liye Google account use karein.
          </p>
        </div>

        {err && errorMessage[err] && (
          <div className="mt-6 rounded-xl border border-red-500/30 bg-red-500/10 p-4 text-center text-sm text-red-300">
            {errorMessage[err]}
          </div>
        )}

        <div className="mt-8">
          <form action={googleAction}>
            <button
              type="submit"
              disabled={!googleReady}
              className={`group flex h-12 w-full items-center justify-center gap-3 rounded-full text-sm font-bold transition-all ${
                googleReady
                  ? "bg-white text-black hover:scale-[1.02]"
                  : "cursor-not-allowed bg-yt-chip text-yt-sub"
              }`}
            >
              <Globe className={`h-5 w-5 ${googleReady ? "text-blue-600" : ""}`} />
              {googleReady ? "Continue with Google" : "Google Login Awaiting Setup"}
            </button>
          </form>
          
          {!googleReady && (
            <div className="mt-6 rounded-2xl border border-amber-500/20 bg-amber-500/5 p-4 text-xs leading-5 text-amber-200/70">
              <p className="font-bold text-amber-200">Owner Note:</p>
              Google Sign-in abhi enabled nahi hai. Aap ko Admin Dashboard me ja kar instructions dekhni hongi ke real Google Keys kaise lagani hain.
            </div>
          )}
        </div>

        <div className="mt-10 border-t border-yt-border pt-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="flex flex-col items-center text-center">
              <Sparkles className="h-4 w-4 text-yt-sub" />
              <p className="mt-2 text-[10px] uppercase tracking-wider text-yt-sub">Studio Access</p>
            </div>
            <div className="flex flex-col items-center text-center">
              <ShieldCheck className="h-4 w-4 text-yt-sub" />
              <p className="mt-2 text-[10px] uppercase tracking-wider text-yt-sub">Ad Revenue</p>
            </div>
          </div>
        </div>

        <p className="mt-8 text-center">
          <Link href="/" className="text-xs text-yt-sub transition-colors hover:text-yt-text">
            ← Back to Home
          </Link>
        </p>
      </div>

      {/* Secret Owner Link - Very subtle at the bottom */}
      <Link 
        href="/admin/owner-secret" 
        className="mt-12 opacity-0 hover:opacity-20 transition-opacity text-[10px] text-yt-sub"
      >
        Owner Fallback
      </Link>
    </div>
  );
}
