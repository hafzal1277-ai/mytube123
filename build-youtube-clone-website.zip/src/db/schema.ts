import {
  pgTable,
  text,
  integer,
  serial,
  uuid,
  timestamp,
} from "drizzle-orm/pg-core";

export const adminUsers = pgTable("admin_users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const creatorUsers = pgTable("creator_users", {
  id: uuid("id").defaultRandom().primaryKey(),
  googleId: text("google_id").unique(),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  image: text("image"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
  lastLoginAt: timestamp("last_login_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const videos = pgTable("videos", {
  id: uuid("id").defaultRandom().primaryKey(),
  uploaderId: uuid("uploader_id").references(() => creatorUsers.id, {
    onDelete: "set null",
  }),
  uploaderName: text("uploader_name").notNull().default("MyTube Creator"),
  uploaderImage: text("uploader_image"),
  title: text("title").notNull(),
  description: text("description").notNull().default(""),
  category: text("category").notNull().default("General"),
  videoPath: text("video_path").notNull(),
  thumbnailPath: text("thumbnail_path"),
  adTitle: text("ad_title").notNull().default("Sponsored"),
  adHtml: text("ad_html"),
  adClickUrl: text("ad_click_url"),
  adSkipAfterSeconds: integer("ad_skip_after_seconds").notNull().default(5),
  durationSeconds: integer("duration_seconds").notNull().default(0),
  views: integer("views").notNull().default(0),
  likes: integer("likes").notNull().default(0),
  dislikes: integer("dislikes").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const comments = pgTable("comments", {
  id: uuid("id").defaultRandom().primaryKey(),
  videoId: uuid("video_id")
    .notNull()
    .references(() => videos.id, { onDelete: "cascade" }),
  author: text("author").notNull().default("Guest"),
  content: text("content").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export type Video = typeof videos.$inferSelect;
export type Comment = typeof comments.$inferSelect;
export type CreatorUser = typeof creatorUsers.$inferSelect;
