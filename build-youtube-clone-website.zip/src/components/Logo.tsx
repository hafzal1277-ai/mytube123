import Link from "next/link";

export default function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <Link
      href="/"
      className="flex items-center gap-1.5 rounded-lg px-1 py-1 outline-none transition-colors focus-visible:ring-2 focus-visible:ring-yt-blue"
      aria-label="MyTube home"
    >
      <span className="relative flex h-6 w-9 items-center justify-center rounded-md bg-yt-red shadow-[0_2px_10px_rgba(255,0,51,0.35)]">
        <svg
          viewBox="0 0 24 24"
          className="h-3.5 w-3.5 translate-x-[1px] fill-white"
          aria-hidden
        >
          <path d="M8 5.7v12.6c0 .9 1 1.5 1.8 1L19.6 13c.7-.5.7-1.5 0-2L9.8 4.7c-.8-.5-1.8.1-1.8 1z" />
        </svg>
      </span>
      {!compact && (
        <span className="flex items-start gap-0.5">
          <span className="text-[19px] font-bold leading-none tracking-tighter text-yt-text">
            MyTube
          </span>
          <span className="mt-[-2px] text-[9px] font-medium leading-none text-yt-sub">
            HD
          </span>
        </span>
      )}
    </Link>
  );
}
