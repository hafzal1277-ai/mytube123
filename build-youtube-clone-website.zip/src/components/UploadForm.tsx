"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  UploadCloud,
  X,
  CheckCircle2,
  Image as ImageIcon,
  Loader2,
  Film,
  RefreshCw,
  ShieldAlert,
} from "lucide-react";
import { CATEGORIES } from "@/lib/constants";

function fmtSize(bytes: number): string {
  if (bytes >= 1024 * 1024 * 1024)
    return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
  if (bytes >= 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${Math.max(1, Math.round(bytes / 1024))} KB`;
}

function fmtDur(sec: number): string {
  const s = Math.round(sec || 0);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const ss = String(s % 60).padStart(2, "0");
  return h > 0
    ? `${h}:${String(m).padStart(2, "0")}:${ss}`
    : `${m}:${ss}`;
}

export default function UploadForm() {
  const router = useRouter();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const thumbInputRef = useRef<HTMLInputElement>(null);
  const urlsRef = useRef<string[]>([]);

  const [dragOver, setDragOver] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [fileURL, setFileURL] = useState<string | null>(null);
  const [duration, setDuration] = useState(0);
  const [thumbBlob, setThumbBlob] = useState<Blob | null>(null);
  const [thumbURL, setThumbURL] = useState<string | null>(null);
  const [customThumb, setCustomThumb] = useState<File | null>(null);
  const [capturing, setCapturing] = useState(false);

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState<string>("General");
  const [adEnabled, setAdEnabled] = useState(false);
  const [adTitle, setAdTitle] = useState("Sponsored");
  const [adClickUrl, setAdClickUrl] = useState("");
  const [adHtml, setAdHtml] = useState("");
  const [adSkipAfter, setAdSkipAfter] = useState(5);

  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [doneId, setDoneId] = useState<string | null>(null);

  const track = useCallback((url: string) => {
    urlsRef.current.push(url);
    return url;
  }, []);

  useEffect(() => {
    const urls = urlsRef.current;
    return () => {
      urls.forEach((u) => URL.revokeObjectURL(u));
    };
  }, []);

  const resetFileFields = useCallback(() => {
    setFile(null);
    setFileURL(null);
    setDuration(0);
    setThumbBlob(null);
    setThumbURL(null);
    setCustomThumb(null);
    setCapturing(false);
    if (fileInputRef.current) fileInputRef.current.value = "";
    if (thumbInputRef.current) thumbInputRef.current.value = "";
  }, []);

  const processVideoFile = useCallback(
    (f: File) => {
      if (!f.type.startsWith("video/")) {
        setError("Yeh video file nahi lagti — MP4/WebM/MOV use karein.");
        return;
      }
      setError(null);
      setDoneId(null);
      resetFileFields();
      setFile(f);
      const url = track(URL.createObjectURL(f));
      setFileURL(url);

      setTitle((t) =>
        t.trim() ? t : f.name.replace(/\.[^.]+$/, "").replace(/[_-]+/g, " ")
      );

      // read metadata + capture thumbnail frame in-browser
      setCapturing(true);
      const v = document.createElement("video");
      v.preload = "metadata";
      v.muted = true;
      v.playsInline = true;
      v.src = url;
      const finish = () => setCapturing(false);
      v.onloadedmetadata = () => {
        if (isFinite(v.duration) && v.duration > 0) {
          setDuration(v.duration);
          v.currentTime = Math.min(5, v.duration * 0.25) || 0.1;
        } else {
          finish();
        }
      };
      v.onseeked = () => {
        try {
          const cw = 1280;
          const ch = 720;
          const canvas = document.createElement("canvas");
          canvas.width = cw;
          canvas.height = ch;
          const ctx = canvas.getContext("2d");
          if (ctx && v.videoWidth > 0) {
            const vw = v.videoWidth;
            const vh = v.videoHeight;
            const scale = Math.max(cw / vw, ch / vh);
            const w = vw * scale;
            const h = vh * scale;
            ctx.drawImage(v, (cw - w) / 2, (ch - h) / 2, w, h);
            canvas.toBlob(
              (blob) => {
                if (blob) {
                  setThumbBlob(blob);
                  setThumbURL(track(URL.createObjectURL(blob)));
                }
                finish();
              },
              "image/jpeg",
              0.85
            );
            return;
          }
        } catch {}
        finish();
      };
      v.onerror = finish;
    },
    [resetFileFields, track]
  );

  function onCustomThumb(f: File | undefined | null) {
    if (!f || !f.type.startsWith("image/")) return;
    setCustomThumb(f);
    setThumbURL(track(URL.createObjectURL(f)));
  }

  function upload() {
    if (!file) {
      setError("Pehle video file select karein.");
      return;
    }
    if (!title.trim()) {
      setError("Video title zaroori hai.");
      return;
    }
    if (adEnabled && !adHtml.trim() && !adClickUrl.trim()) {
      setError("Ad enable karne par Adsterra HTML code ya ad link dena zaroori hai.");
      return;
    }
    if (uploading) return;

    setUploading(true);
    setProgress(0);
    setError(null);

    const fd = new FormData();
    fd.append("title", title.trim());
    fd.append("description", description.trim());
    fd.append("category", category);
    fd.append("durationSeconds", String(Math.round(duration || 0)));
    fd.append("adEnabled", adEnabled ? "1" : "0");
    fd.append("adTitle", adTitle.trim() || "Sponsored");
    fd.append("adClickUrl", adClickUrl.trim());
    fd.append("adHtml", adHtml.trim());
    fd.append("adSkipAfterSeconds", String(adSkipAfter));
    fd.append("video", file, file.name);
    const thumb: Blob | null = customThumb || thumbBlob;
    if (thumb) {
      const name =
        customThumb && customThumb.name ? customThumb.name : "thumbnail.jpg";
      fd.append("thumbnail", thumb, name);
    }

    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/api/videos/upload");
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) {
        setProgress(Math.round((e.loaded / e.total) * 100));
      }
    };
    xhr.onload = () => {
      setUploading(false);
      try {
        const data = JSON.parse(xhr.responseText || "{}");
        if (xhr.status >= 200 && xhr.status < 300 && data.ok) {
          setDoneId(data.video.id as string);
          resetFileFields();
          setTitle("");
          setDescription("");
          setCategory("General");
          setAdEnabled(false);
          setAdTitle("Sponsored");
          setAdClickUrl("");
          setAdHtml("");
          setAdSkipAfter(5);
          router.refresh();
        } else {
          setError(data.error || `Upload failed (${xhr.status})`);
        }
      } catch {
        setError(`Upload failed (${xhr.status})`);
      }
    };
    xhr.onerror = () => {
      setUploading(false);
      setError("Network error — dobara koshish karein");
    };
    xhr.send(fd);
  }

  /* ------------------------------ success state ----------------------------- */
  if (doneId) {
    return (
      <div className="mx-auto max-w-2xl animate-pop-in rounded-3xl border border-yt-border bg-[#141414] p-10 text-center">
        <span className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-emerald-500/15">
          <CheckCircle2 className="h-10 w-10 text-emerald-400" />
        </span>
        <h2 className="mt-6 text-2xl font-bold text-yt-text">
          Video publish ho gayi!
        </h2>
        <p className="mt-2 text-sm text-yt-sub">
          Aapki video ab site par live hai aur koi bhi dekh sakta hai.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Link
            href={`/watch?v=${doneId}`}
            className="flex h-11 items-center gap-2 rounded-full bg-white px-6 text-sm font-bold text-black transition-transform hover:scale-[1.03]"
          >
            <Film className="h-4 w-4" />
            Watch video
          </Link>
          <button
            onClick={() => setDoneId(null)}
            className="flex h-11 items-center gap-2 rounded-full border border-yt-border px-6 text-sm font-medium text-yt-text transition-colors hover:bg-yt-chip"
          >
            <RefreshCw className="h-4 w-4" />
            Upload another
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl">
      {/* dropzone */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOver(false);
          const f = e.dataTransfer.files?.[0];
          if (f) processVideoFile(f);
        }}
        className={`flex flex-col items-center justify-center rounded-3xl border-2 border-dashed px-6 py-12 text-center transition-colors ${
          dragOver
            ? "border-yt-blue bg-[#102a43]/40"
            : "border-yt-border bg-[#141414] hover:border-[#3d3d3d]"
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept="video/*"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) processVideoFile(f);
          }}
        />
        <span
          className={`flex h-20 w-20 items-center justify-center rounded-full transition-colors ${
            dragOver ? "bg-yt-blue/20" : "bg-yt-chip"
          }`}
        >
          <UploadCloud
            className={`h-9 w-9 ${dragOver ? "text-yt-blue" : "text-yt-sub"}`}
          />
        </span>
        <p className="mt-5 text-lg font-medium text-yt-text">
          Apni video yahan drag & drop karein
        </p>
        <p className="mt-1 text-sm text-yt-sub">
          MP4, WebM, MOV — max 4GB tak
        </p>
        <button
          onClick={() => fileInputRef.current?.click()}
          disabled={uploading}
          className="mt-6 h-11 rounded-full bg-white px-8 text-sm font-bold text-black transition-transform hover:scale-[1.03] active:scale-95"
        >
          Select file
        </button>
      </div>

      {/* selected file + details */}
      {file && (
        <div className="mt-6 grid grid-cols-1 gap-6 animate-fade-up lg:grid-cols-[minmax(0,380px)_1fr]">
          {/* preview column */}
          <div>
            {fileURL && (
              <video
                src={fileURL}
                controls
                muted
                className="aspect-video w-full rounded-xl bg-black"
              />
            )}
            <div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-yt-sub">
              <span className="rounded bg-yt-chip px-2 py-1">{file.name}</span>
              <span className="rounded bg-yt-chip px-2 py-1">
                {fmtSize(file.size)}
              </span>
              {duration > 0 && (
                <span className="rounded bg-yt-chip px-2 py-1">
                  {fmtDur(duration)}
                </span>
              )}
              <button
                onClick={() => {
                  resetFileFields();
                  setError(null);
                }}
                disabled={uploading}
                className="ml-auto flex items-center gap-1 rounded-full border border-yt-border px-3 py-1 font-medium text-yt-sub transition-colors hover:bg-yt-chip hover:text-yt-text"
              >
                <X className="h-3.5 w-3.5" />
                Remove
              </button>
            </div>

            {/* thumbnail */}
            <div className="mt-5">
              <div className="mb-2 flex items-center justify-between">
                <p className="text-xs font-medium uppercase tracking-wider text-yt-sub">
                  Thumbnail
                </p>
                <button
                  onClick={() => thumbInputRef.current?.click()}
                  disabled={uploading}
                  className="flex items-center gap-1.5 rounded-full border border-yt-border px-3 py-1 text-xs font-medium text-yt-sub transition-colors hover:bg-yt-chip hover:text-yt-text"
                >
                  <ImageIcon className="h-3.5 w-3.5" />
                  {thumbURL ? "Replace" : "Choose image"}
                </button>
                <input
                  ref={thumbInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => onCustomThumb(e.target.files?.[0])}
                />
              </div>
              <div className="relative aspect-video w-full overflow-hidden rounded-xl border border-yt-border bg-yt-chip">
                {capturing && !thumbURL && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 text-yt-sub">
                    <Loader2 className="h-5 w-5 animate-spin" />
                    <span className="text-xs">Frame capture ho rahi hai...</span>
                  </div>
                )}
                {thumbURL ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={thumbURL}
                    alt="Thumbnail"
                    className="h-full w-full object-cover"
                  />
                ) : (
                  !capturing && (
                    <div className="absolute inset-0 flex items-center justify-center text-xs text-yt-sub">
                      Video frame auto-capture ya custom image
                    </div>
                  )
                )}
              </div>
              <p className="mt-1.5 text-xs text-yt-sub">
                {customThumb
                  ? "Custom image set ho gayi."
                  : thumbBlob
                    ? "Video se auto-captured frame — chahein to replace karein."
                    : "Na choose karne par default thumbnail use hogi."}
              </p>
            </div>
          </div>

          {/* form column */}
          <div className="flex flex-col gap-4 rounded-2xl border border-yt-border bg-[#141414] p-5">
            <label className="block">
              <span className="mb-1.5 flex items-center justify-between text-xs font-medium uppercase tracking-wider text-yt-sub">
                Title <span>{title.length}/150</span>
              </span>
              <input
                value={title}
                onChange={(e) => setTitle(e.target.value.slice(0, 150))}
                placeholder="Video ka title likhein"
                disabled={uploading}
                className="h-11 w-full rounded-lg border border-yt-border bg-[#0f0f0f] px-4 text-sm text-yt-text outline-none transition-colors placeholder:text-yt-sub/60 focus:border-yt-blue"
              />
            </label>

            <label className="block">
              <span className="mb-1.5 flex items-center justify-between text-xs font-medium uppercase tracking-wider text-yt-sub">
                Description <span>{description.length}/5000</span>
              </span>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value.slice(0, 5000))}
                rows={5}
                placeholder="Viewers ko video ke baare mein batayein"
                disabled={uploading}
                className="w-full resize-none rounded-lg border border-yt-border bg-[#0f0f0f] p-4 text-sm leading-6 text-yt-text outline-none transition-colors placeholder:text-yt-sub/60 focus:border-yt-blue"
              />
            </label>

            <label className="block">
              <span className="mb-1.5 block text-xs font-medium uppercase tracking-wider text-yt-sub">
                Category
              </span>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                disabled={uploading}
                className="h-11 w-full rounded-lg border border-yt-border bg-[#0f0f0f] px-4 text-sm text-yt-text outline-none focus:border-yt-blue"
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </label>

            <div className="rounded-2xl border border-yt-border bg-[#101010] p-4">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="text-sm font-semibold text-yt-text">
                    Pre-roll ad before video
                  </p>
                  <p className="mt-1 text-xs leading-5 text-yt-sub">
                    Yahan Adsterra ka HTML code ya ad link paste karein. Viewer ko pehle ad nazar aayegi, phir close ya skip karke video play hogi.
                  </p>
                </div>
                <label className="inline-flex cursor-pointer items-center gap-2 rounded-full bg-yt-chip px-3 py-2 text-xs font-medium text-yt-text">
                  <input
                    type="checkbox"
                    checked={adEnabled}
                    onChange={(e) => setAdEnabled(e.target.checked)}
                    className="h-4 w-4 accent-yt-red"
                  />
                  Enable ad
                </label>
              </div>

              {adEnabled && (
                <div className="mt-4 flex flex-col gap-4">
                  <label className="block">
                    <span className="mb-1.5 block text-xs font-medium uppercase tracking-wider text-yt-sub">
                      Ad title
                    </span>
                    <input
                      value={adTitle}
                      onChange={(e) => setAdTitle(e.target.value.slice(0, 120))}
                      placeholder="Sponsored / Adsterra Offer"
                      disabled={uploading}
                      className="h-11 w-full rounded-lg border border-yt-border bg-[#0f0f0f] px-4 text-sm text-yt-text outline-none focus:border-yt-blue"
                    />
                  </label>

                  <label className="block">
                    <span className="mb-1.5 block text-xs font-medium uppercase tracking-wider text-yt-sub">
                      Ad click link (optional)
                    </span>
                    <input
                      value={adClickUrl}
                      onChange={(e) => setAdClickUrl(e.target.value.slice(0, 1000))}
                      placeholder="https://your-adsterra-link.example"
                      disabled={uploading}
                      className="h-11 w-full rounded-lg border border-yt-border bg-[#0f0f0f] px-4 text-sm text-yt-text outline-none focus:border-yt-blue"
                    />
                  </label>

                  <label className="block">
                    <span className="mb-1.5 flex items-center justify-between text-xs font-medium uppercase tracking-wider text-yt-sub">
                      Adsterra HTML / script / iframe code
                      <span>{adHtml.length}/40000</span>
                    </span>
                    <textarea
                      value={adHtml}
                      onChange={(e) => setAdHtml(e.target.value.slice(0, 40000))}
                      rows={7}
                      placeholder="Yahan apna Adsterra ad code paste karein..."
                      disabled={uploading}
                      className="w-full resize-y rounded-lg border border-yt-border bg-[#0f0f0f] p-4 font-mono text-xs leading-6 text-yt-text outline-none focus:border-yt-blue"
                    />
                  </label>

                  <label className="block">
                    <span className="mb-1.5 flex items-center justify-between text-xs font-medium uppercase tracking-wider text-yt-sub">
                      Skip button after
                      <span>{adSkipAfter}s</span>
                    </span>
                    <input
                      type="range"
                      min={1}
                      max={15}
                      step={1}
                      value={adSkipAfter}
                      onChange={(e) => setAdSkipAfter(Number(e.target.value))}
                      className="yt-range w-full"
                    />
                  </label>

                  <div className="rounded-xl border border-dashed border-yt-border p-3 text-xs leading-5 text-yt-sub">
                    Tip: Agar aap Adsterra ka iframe/script code paste karte hain to woh viewer ko video se pehle sandboxed ad frame mein show hoga. Agar sirf link doge to branded sponsor screen show hogi.
                  </div>
                </div>
              )}
            </div>

            {error && (
              <div className="flex items-start gap-2 rounded-lg border border-yt-red/40 bg-yt-red/10 p-3 text-sm text-[#ff8a9d]">
                <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0" />
                {error}
              </div>
            )}

            {/* progress */}
            {uploading && (
              <div>
                <div className="mb-1.5 flex items-center justify-between text-xs text-yt-sub">
                  <span className="flex items-center gap-1.5">
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    Uploading {file.name}...
                  </span>
                  <span className="font-medium text-yt-text">{progress}%</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-yt-chip">
                  <div
                    className="h-full rounded-full bg-yt-red transition-all duration-300"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>
            )}

            <div className="mt-1 flex items-center justify-end gap-3">
              <button
                onClick={() => {
                  resetFileFields();
                  setTitle("");
                  setDescription("");
                  setAdEnabled(false);
                  setAdTitle("Sponsored");
                  setAdClickUrl("");
                  setAdHtml("");
                  setAdSkipAfter(5);
                  setError(null);
                }}
                disabled={uploading}
                className="h-11 rounded-full px-6 text-sm font-medium text-yt-text transition-colors hover:bg-yt-chip"
              >
                Cancel
              </button>
              <button
                onClick={upload}
                disabled={uploading || !file || !title.trim()}
                className={`flex h-11 items-center gap-2 rounded-full px-8 text-sm font-bold transition-all ${
                  uploading || !file || !title.trim()
                    ? "cursor-not-allowed bg-yt-chip text-yt-sub"
                    : "bg-yt-red text-white hover:scale-[1.03] hover:bg-[#e6002e] active:scale-95"
                }`}
              >
                {uploading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <UploadCloud className="h-4 w-4" />
                )}
                {uploading ? "Publishing..." : "Publish video"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
