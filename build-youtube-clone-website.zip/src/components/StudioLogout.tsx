"use client";

import { LogOut } from "lucide-react";

export default function StudioLogout({
  authProvider,
}: {
  authProvider: "google" | "admin";
}) {
  async function handleLogout() {
    if (authProvider === "google") {
      const { signOut } = await import("next-auth/react");
      await signOut({ callbackUrl: "/" });
      return;
    }
    await fetch("/api/auth/logout", {
      method: "POST",
      credentials: "same-origin",
    });
    window.location.href = "/admin/login";
  }

  return (
    <button
      onClick={() => void handleLogout()}
      className="flex h-9 items-center gap-2 rounded-full border border-yt-border px-4 text-sm font-medium text-yt-sub transition-colors hover:bg-yt-chip hover:text-yt-text"
    >
      <LogOut className="h-4 w-4" />
      Sign out
    </button>
  );
}
