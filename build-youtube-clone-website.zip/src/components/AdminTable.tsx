"use client";

import { useState } from "react";
import Link from "next/link";
import {
  Pencil,
  Play,
  Trash2,
  VideoOff,
  X,
  Loader2,
  AlertTriangle,
  Globe,
} from "lucide-react";
import { CATEGORIES } from "@/lib/constants";

export type AdminVideoItem = {
  id: string;
  title: string;
  description: string;
  category: string;
  thumbnail: string | null;
  durationLabel: string;
  viewsLabel: string;
  views: number;
  likes: number;
  dateLabel: string;
  ownerName?: string;
};

export default function AdminTable({
  items: initialItems,
  adminName,
}: {
  items: AdminVideoItem[];
  adminName: string;
}) {
  const [items, setItems] = useState(initialItems);
  const [deleteTarget, setDeleteTarget] = useState<AdminVideoItem | null>(null);
  const [editTarget, setEditTarget] = useState<AdminVideoItem | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [editTitle, setEditTitle] = useState("");
  const [editDesc, setEditDesc] = useState("");
  const [editCat, setEditCat] = useState("General");

  function openEdit(item: AdminVideoItem) {
    setEditTarget(item);
    setEditTitle(item.title);
    setEditDesc(item.description);
    setEditCat(item.category);
    setError(null);
  }

  async function confirmDelete() {
    if (!deleteTarget || busy) return;
    setBusy(true);
    try {
      const res = await fetch(`/api/videos/${deleteTarget.id}`, {
        method: "DELETE",
      });
      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error || "Delete failed");
      }
      setItems((l) => l.filter((v) => v.id !== deleteTarget.id));
      setDeleteTarget(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Delete failed");
    } finally {
      setBusy(false);
    }
  }

  async function saveEdit() {
    if (!editTarget || busy) return;
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(`/api/videos/${editTarget.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: editTitle,
          description: editDesc,
          category: editCat,
        }),
      });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || "Save failed");
      setItems((l) =>
        l.map((v) =>
          v.id === editTarget.id
            ? {
                ...v,
                title: d.video.title,
                description: d.video.description,
                category: d.video.category,
              }
            : v
        )
      );
      setEditTarget(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Save failed");
    } finally {
      setBusy(false);
    }
  }

  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center rounded-2xl border border-dashed border-yt-border py-20 text-center">
        <span className="flex h-16 w-16 items-center justify-center rounded-full bg-yt-chip">
          <VideoOff className="h-7 w-7 text-yt-sub" />
        </span>
        <p className="mt-4 font-medium text-yt-text">Abhi koi video nahi</p>
        <p className="mt-1 text-sm text-yt-sub">
          {adminName}, pehli video upload kar ke shuru karein!
        </p>
        <Link
          href="/admin/upload"
          className="mt-5 flex h-9 items-center rounded-full bg-white px-5 text-sm font-medium text-black transition-transform hover:scale-[1.03]"
        >
          Upload video
        </Link>
      </div>
    );
  }

  return (
    <>
      {/* desktop table */}
      <div className="hidden overflow-hidden rounded-2xl border border-yt-border md:block">
        <div className="yt-scroll overflow-x-auto">
          <table className="w-full min-w-[820px] text-left text-sm">
            <thead>
              <tr className="border-b border-yt-border bg-[#141414] text-xs uppercase tracking-wider text-yt-sub">
                <th className="px-4 py-3 font-medium">Video</th>
                <th className="px-4 py-3 font-medium">Visibility</th>
                <th className="px-4 py-3 font-medium">Date</th>
                <th className="px-4 py-3 text-right font-medium">Views</th>
                <th className="px-4 py-3 text-right font-medium">Likes</th>
                <th className="px-4 py-3 text-right font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {items.map((v) => (
                <tr
                  key={v.id}
                  className="group border-b border-yt-chip/60 transition-colors last:border-0 hover:bg-[#161616]"
                >
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="relative h-[54px] w-24 shrink-0 overflow-hidden rounded-lg bg-yt-chip">
                        {v.thumbnail ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img
                            src={v.thumbnail}
                            alt=""
                            className="h-full w-full object-cover"
                          />
                        ) : (
                          <span className="flex h-full w-full items-center justify-center text-[10px] text-yt-sub">
                            No thumb
                          </span>
                        )}
                        <span className="absolute bottom-1 right-1 rounded bg-black/80 px-1 text-[10px] font-medium text-white">
                          {v.durationLabel}
                        </span>
                      </div>
                      <div className="min-w-0">
                        <p className="line-clamp-1 max-w-[280px] font-medium text-yt-text">
                          {v.title}
                        </p>
                        <p className="mt-0.5 line-clamp-1 max-w-[280px] text-xs text-yt-sub">
                          {v.description || "No description"}
                        </p>
                        <div className="mt-1 flex flex-wrap items-center gap-1.5">
                          <span className="inline-block rounded bg-yt-chip px-1.5 py-0.5 text-[10px] font-medium text-yt-sub">
                            {v.category}
                          </span>
                          {v.ownerName && (
                            <span className="inline-block rounded bg-[#1c1c1c] px-1.5 py-0.5 text-[10px] font-medium text-yt-sub">
                              by {v.ownerName}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className="flex items-center gap-1.5 text-xs text-yt-sub">
                      <Globe className="h-3.5 w-3.5 text-emerald-400" />
                      Public
                    </span>
                  </td>
                  <td className="whitespace-nowrap px-4 py-3 text-xs text-yt-sub">
                    {v.dateLabel}
                  </td>
                  <td className="px-4 py-3 text-right text-yt-text">
                    {v.viewsLabel}
                  </td>
                  <td className="px-4 py-3 text-right text-yt-text">
                    {v.likes}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-1">
                      <Link
                        href={`/watch?v=${v.id}`}
                        title="Watch"
                        className="rounded-full p-2 text-yt-sub transition-colors hover:bg-yt-chip hover:text-yt-text"
                      >
                        <Play className="h-4 w-4" />
                      </Link>
                      <button
                        onClick={() => openEdit(v)}
                        title="Edit"
                        className="rounded-full p-2 text-yt-sub transition-colors hover:bg-yt-chip hover:text-yt-text"
                      >
                        <Pencil className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => {
                          setDeleteTarget(v);
                          setError(null);
                        }}
                        title="Delete"
                        className="rounded-full p-2 text-yt-sub transition-colors hover:bg-yt-red/15 hover:text-yt-red"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* mobile cards */}
      <div className="flex flex-col gap-3 md:hidden">
        {items.map((v) => (
          <div
            key={v.id}
            className="flex gap-3 rounded-2xl border border-yt-border bg-[#141414] p-3"
          >
            <div className="relative h-16 w-28 shrink-0 overflow-hidden rounded-lg bg-yt-chip">
              {v.thumbnail ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={v.thumbnail}
                  alt=""
                  className="h-full w-full object-cover"
                />
              ) : (
                <span className="flex h-full w-full items-center justify-center text-[10px] text-yt-sub">
                  No thumb
                </span>
              )}
              <span className="absolute bottom-1 right-1 rounded bg-black/80 px-1 text-[10px] text-white">
                {v.durationLabel}
              </span>
            </div>
            <div className="min-w-0 flex-1">
              <p className="line-clamp-2 text-sm font-medium text-yt-text">
                {v.title}
              </p>
              <p className="mt-1 text-xs text-yt-sub">
                {v.viewsLabel} views • {v.dateLabel}
              </p>
              <div className="mt-2 flex gap-1">
                <Link
                  href={`/watch?v=${v.id}`}
                  className="rounded-full p-1.5 text-yt-sub hover:bg-yt-chip hover:text-yt-text"
                >
                  <Play className="h-4 w-4" />
                </Link>
                <button
                  onClick={() => openEdit(v)}
                  className="rounded-full p-1.5 text-yt-sub hover:bg-yt-chip hover:text-yt-text"
                >
                  <Pencil className="h-4 w-4" />
                </button>
                <button
                  onClick={() => {
                    setDeleteTarget(v);
                    setError(null);
                  }}
                  className="rounded-full p-1.5 text-yt-sub hover:bg-yt-red/15 hover:text-yt-red"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* delete modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-black/70"
            onClick={() => !busy && setDeleteTarget(null)}
          />
          <div className="relative w-full max-w-sm animate-pop-in rounded-2xl border border-yt-border bg-[#181818] p-6">
            <span className="flex h-12 w-12 items-center justify-center rounded-full bg-yt-red/15">
              <AlertTriangle className="h-6 w-6 text-yt-red" />
            </span>
            <h3 className="mt-4 text-lg font-bold text-yt-text">
              Delete video?
            </h3>
            <p className="mt-2 text-sm leading-6 text-yt-sub">
              <span className="font-medium text-yt-text">
                &ldquo;{deleteTarget.title}&rdquo;
              </span>{" "}
              permanently delete ho jayegi (file + comments). Yeh action undo
              nahi ho sakta.
            </p>
            {error && <p className="mt-3 text-sm text-yt-red">{error}</p>}
            <div className="mt-6 flex justify-end gap-2">
              <button
                onClick={() => setDeleteTarget(null)}
                disabled={busy}
                className="h-10 rounded-full px-5 text-sm font-medium text-yt-text transition-colors hover:bg-yt-chip"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                disabled={busy}
                className="flex h-10 items-center gap-2 rounded-full bg-yt-red px-5 text-sm font-bold text-white transition-colors hover:bg-[#e6002e]"
              >
                {busy && <Loader2 className="h-4 w-4 animate-spin" />}
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* edit modal */}
      {editTarget && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-black/70"
            onClick={() => !busy && setEditTarget(null)}
          />
          <div className="yt-scroll relative max-h-[90vh] w-full max-w-lg animate-pop-in overflow-y-auto rounded-2xl border border-yt-border bg-[#181818] p-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-yt-text">Edit video</h3>
              <button
                onClick={() => setEditTarget(null)}
                className="rounded-full p-2 text-yt-sub transition-colors hover:bg-yt-chip hover:text-yt-text"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="mt-5 flex flex-col gap-4">
              <label className="block">
                <span className="mb-1.5 block text-xs font-medium uppercase tracking-wider text-yt-sub">
                  Title
                </span>
                <input
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value.slice(0, 150))}
                  className="h-11 w-full rounded-lg border border-yt-border bg-[#0f0f0f] px-4 text-sm text-yt-text outline-none focus:border-yt-blue"
                />
              </label>
              <label className="block">
                <span className="mb-1.5 block text-xs font-medium uppercase tracking-wider text-yt-sub">
                  Description
                </span>
                <textarea
                  value={editDesc}
                  onChange={(e) => setEditDesc(e.target.value.slice(0, 5000))}
                  rows={4}
                  className="w-full resize-none rounded-lg border border-yt-border bg-[#0f0f0f] p-4 text-sm text-yt-text outline-none focus:border-yt-blue"
                />
              </label>
              <label className="block">
                <span className="mb-1.5 block text-xs font-medium uppercase tracking-wider text-yt-sub">
                  Category
                </span>
                <select
                  value={editCat}
                  onChange={(e) => setEditCat(e.target.value)}
                  className="h-11 w-full rounded-lg border border-yt-border bg-[#0f0f0f] px-4 text-sm text-yt-text outline-none focus:border-yt-blue"
                >
                  {CATEGORIES.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </label>
            </div>

            {error && <p className="mt-4 text-sm text-yt-red">{error}</p>}

            <div className="mt-6 flex justify-end gap-2">
              <button
                onClick={() => setEditTarget(null)}
                disabled={busy}
                className="h-10 rounded-full px-5 text-sm font-medium text-yt-text transition-colors hover:bg-yt-chip"
              >
                Cancel
              </button>
              <button
                onClick={saveEdit}
                disabled={busy || !editTitle.trim()}
                className="flex h-10 items-center gap-2 rounded-full bg-white px-5 text-sm font-bold text-black transition-transform hover:scale-[1.03] disabled:cursor-not-allowed disabled:bg-yt-chip disabled:text-yt-sub"
              >
                {busy && <Loader2 className="h-4 w-4 animate-spin" />}
                Save changes
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
