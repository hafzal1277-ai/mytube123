"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  Minimize,
  RotateCcw,
  Loader2,
} from "lucide-react";

function fmt(t: number): string {
  const s = Math.max(0, Math.floor(t || 0));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const ss = String(s % 60).padStart(2, "0");
  return h > 0
    ? `${h}:${String(m).padStart(2, "0")}:${ss}`
    : `${m}:${ss}`;
}

export default function VideoPlayer({
  src,
  poster,
  onFirstPlay,
}: {
  src: string;
  poster: string | null;
  onFirstPlay?: () => void;
}) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const hideTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const firstPlaySent = useRef(false);

  const [started, setStarted] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [buffering, setBuffering] = useState(false);
  const [ended, setEnded] = useState(false);
  const [time, setTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [buffered, setBuffered] = useState(0);
  const [volume, setVolume] = useState(1);
  const [muted, setMuted] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);
  const [controlsVisible, setControlsVisible] = useState(true);

  const togglePlay = useCallback(() => {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) v.play().catch(() => {});
    else v.pause();
  }, []);

  const toggleFullscreen = useCallback(() => {
    const el = wrapRef.current;
    if (!el) return;
    if (document.fullscreenElement) {
      document.exitFullscreen().catch(() => {});
    } else {
      el.requestFullscreen().catch(() => {});
    }
  }, []);

  const pokeControls = useCallback(() => {
    setControlsVisible(true);
    if (hideTimer.current) clearTimeout(hideTimer.current);
    hideTimer.current = setTimeout(() => {
      const v = videoRef.current;
      if (v && !v.paused && !v.ended) setControlsVisible(false);
    }, 2600);
  }, []);

  // Autoplay attempt (on by default like YouTube). Falls back to click-to-play.
  useEffect(() => {
    const v = videoRef.current;
    if (v) v.play().catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [src]);

  useEffect(() => {
    const onFs = () => setFullscreen(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", onFs);
    return () => document.removeEventListener("fullscreenchange", onFs);
  }, []);

  useEffect(() => {
    return () => {
      if (hideTimer.current) clearTimeout(hideTimer.current);
    };
  }, []);

  function handlePlay() {
    setPlaying(true);
    setStarted(true);
    setEnded(false);
    pokeControls();
    if (!firstPlaySent.current) {
      firstPlaySent.current = true;
      onFirstPlay?.();
    }
  }

  function seekFromEvent(e: React.PointerEvent<HTMLDivElement>) {
    const v = videoRef.current;
    const rect = e.currentTarget.getBoundingClientRect();
    const ratio = Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width));
    if (v && v.duration) {
      v.currentTime = ratio * v.duration;
      setTime(v.currentTime);
    }
  }

  function onKeyDown(e: React.KeyboardEvent) {
    const v = videoRef.current;
    if (!v) return;
    if (e.key === " " || e.key.toLowerCase() === "k") {
      e.preventDefault();
      togglePlay();
    } else if (e.key === "ArrowRight") {
      v.currentTime = Math.min(v.duration || 0, v.currentTime + 5);
    } else if (e.key === "ArrowLeft") {
      v.currentTime = Math.max(0, v.currentTime - 5);
    } else if (e.key.toLowerCase() === "f") {
      toggleFullscreen();
    } else if (e.key.toLowerCase() === "m") {
      v.muted = !v.muted;
      setMuted(v.muted);
    }
  }

  const progress = duration > 0 ? (time / duration) * 100 : 0;
  const bufferedPct = duration > 0 ? (buffered / duration) * 100 : 0;

  return (
    <div
      ref={wrapRef}
      tabIndex={0}
      onKeyDown={onKeyDown}
      onMouseMove={pokeControls}
      onClick={togglePlay}
      onDoubleClick={toggleFullscreen}
      className={`relative aspect-video w-full cursor-pointer select-none overflow-hidden bg-black outline-none ${
        fullscreen ? "" : "sm:rounded-xl"
      }`}
    >
      <video
        ref={videoRef}
        src={src}
        poster={poster || undefined}
        preload="metadata"
        playsInline
        className="h-full w-full"
        onPlay={handlePlay}
        onPause={() => {
          setPlaying(false);
          setControlsVisible(true);
        }}
        onTimeUpdate={(e) => setTime(e.currentTarget.currentTime)}
        onLoadedMetadata={(e) => setDuration(e.currentTarget.duration)}
        onProgress={(e) => {
          const v = e.currentTarget;
          if (v.buffered.length > 0)
            setBuffered(v.buffered.end(v.buffered.length - 1));
        }}
        onWaiting={() => setBuffering(true)}
        onPlaying={() => setBuffering(false)}
        onEnded={() => {
          setEnded(true);
          setControlsVisible(true);
        }}
      />

      {/* initial big play overlay */}
      {!started && !playing && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center bg-gradient-to-b from-black/20 via-transparent to-black/40">
          <span className="flex h-16 w-16 items-center justify-center rounded-full bg-yt-red shadow-[0_8px_30px_rgba(255,0,51,0.5)] transition-transform duration-300 sm:h-20 sm:w-20">
            <Play className="h-8 w-8 translate-x-[2px] fill-white text-white" />
          </span>
        </div>
      )}

      {/* buffering spinner */}
      {buffering && started && !ended && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <Loader2 className="h-10 w-10 animate-spin text-white/90" />
        </div>
      )}

      {/* ended replay */}
      {ended && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center bg-black/40">
          <span className="flex h-16 w-16 items-center justify-center rounded-full bg-white/15 backdrop-blur-sm">
            <RotateCcw className="h-7 w-7 text-white" />
          </span>
        </div>
      )}

      {/* controls */}
      <div
        onClick={(e) => e.stopPropagation()}
        onDoubleClick={(e) => e.stopPropagation()}
        className={`absolute inset-x-0 bottom-0 px-3 pb-2 pt-10 transition-opacity duration-200 ${
          controlsVisible || !playing ? "opacity-100" : "opacity-0"
        }`}
        style={{
          background:
            "linear-gradient(to top, rgba(0,0,0,0.85), rgba(0,0,0,0.35) 60%, transparent)",
        }}
      >
        {/* progress */}
        <div
          className="group/bar relative mb-1 h-4 cursor-pointer"
          onPointerDown={(e) => {
            e.currentTarget.setPointerCapture(e.pointerId);
            seekFromEvent(e);
          }}
          onPointerMove={(e) => {
            if (e.buttons === 1) seekFromEvent(e);
          }}
        >
          <div className="absolute inset-x-0 top-1/2 h-[3px] -translate-y-1/2 rounded-full bg-white/25 transition-all group-hover/bar:h-[5px]">
            <div
              className="absolute left-0 top-0 h-full rounded-full bg-white/30"
              style={{ width: `${bufferedPct}%` }}
            />
            <div
              className="absolute left-0 top-0 h-full rounded-full bg-yt-red"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div
            className="absolute top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-yt-red opacity-0 transition-opacity group-hover/bar:opacity-100"
            style={{ left: `${progress}%` }}
          />
        </div>

        <div className="flex items-center gap-1 sm:gap-2">
          <button
            onClick={togglePlay}
            className="rounded-full p-2 text-white transition-colors hover:bg-white/10"
            aria-label={playing ? "Pause" : "Play"}
          >
            {playing ? (
              <Pause className="h-5 w-5 fill-white" />
            ) : (
              <Play className="h-5 w-5 fill-white" />
            )}
          </button>

          <div className="flex items-center">
            <button
              onClick={() => {
                const v = videoRef.current;
                if (!v) return;
                v.muted = !v.muted;
                setMuted(v.muted);
              }}
              className="rounded-full p-2 text-white transition-colors hover:bg-white/10"
              aria-label={muted ? "Unmute" : "Mute"}
            >
              {muted || volume === 0 ? (
                <VolumeX className="h-5 w-5" />
              ) : (
                <Volume2 className="h-5 w-5" />
              )}
            </button>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={muted ? 0 : volume}
              onChange={(e) => {
                const val = Number(e.target.value);
                const v = videoRef.current;
                if (!v) return;
                v.volume = val;
                v.muted = val === 0;
                setVolume(val);
                setMuted(val === 0);
              }}
              className="yt-range hidden w-16 sm:block"
              aria-label="Volume"
            />
          </div>

          <span className="ml-1 text-xs font-medium text-white/90">
            {fmt(time)} / {fmt(duration)}
          </span>

          <div className="flex-1" />

          <button
            onClick={toggleFullscreen}
            className="rounded-full p-2 text-white transition-colors hover:bg-white/10"
            aria-label="Fullscreen"
          >
            {fullscreen ? (
              <Minimize className="h-5 w-5" />
            ) : (
              <Maximize className="h-5 w-5" />
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
