"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import {
  ThumbsUp,
  ThumbsDown,
  Share2,
  Download,
  Bell,
  Check,
  BadgeCheck,
  FilePenLine,
} from "lucide-react";
import Comments, { type SerializedComment } from "./Comments";
import { ChannelAvatar } from "./VideoCard";
import PreRollPlayer from "./PreRollPlayer";
import type { PreRollConfig } from "@/lib/ads";

type Reaction = "like" | "dislike" | null;

function fmtViewsLocal(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1).replace(/\.0$/, "")}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1).replace(/\.0$/, "")}K`;
  return `${n}`;
}

export default function WatchClient({
  video,
  initialComments,
  canManage,
  ad,
}: {
  video: {
    id: string;
    title: string;
    src: string;
    poster: string | null;
    views: number;
    likes: number;
    dislikes: number;
    category: string;
    description: string;
    dateLabel: string;
    channelName: string;
    channelImage: string | null;
  };
  initialComments: SerializedComment[];
  canManage: boolean;
  ad: PreRollConfig;
}) {
  const [views, setViews] = useState(video.views);
  const [likes, setLikes] = useState(video.likes);
  const [dislikes, setDislikes] = useState(video.dislikes);
  const [reaction, setReaction] = useState<Reaction>(null);
  const [subscribed, setSubscribed] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    try {
      const r = localStorage.getItem(`mytube:reaction:${video.id}`);
      if (r === "like" || r === "dislike") setReaction(r);
      if (localStorage.getItem(`mytube:subscribed:${video.channelName}`) === "1") {
        setSubscribed(true);
      }
    } catch {}
    return () => {
      if (toastTimer.current) clearTimeout(toastTimer.current);
    };
  }, [video.id, video.channelName]);

  function showToast(msg: string) {
    setToast(msg);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 2000);
  }

  function handleFirstPlay() {
    try {
      const key = `mytube:viewed:${video.id}`;
      if (sessionStorage.getItem(key)) return;
      sessionStorage.setItem(key, "1");
    } catch {}
    fetch(`/api/videos/${video.id}/view`, { method: "POST" })
      .then((r) => r.json())
      .then((d) => {
        if (typeof d.views === "number") setViews(d.views);
      })
      .catch(() => {});
  }

  async function toggleReaction(r: "like" | "dislike") {
    const prev = reaction;
    const next: Reaction = reaction === r ? null : r;
    setReaction(next);
    try {
      const res = await fetch(`/api/videos/${video.id}/react`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ next, prev }),
      });
      const d = await res.json();
      if (typeof d.likes === "number") setLikes(d.likes);
      if (typeof d.dislikes === "number") setDislikes(d.dislikes);
      try {
        const key = `mytube:reaction:${video.id}`;
        if (next) localStorage.setItem(key, next);
        else localStorage.removeItem(key);
      } catch {}
    } catch {
      setReaction(prev);
    }
  }

  async function share() {
    const url = window.location.href;
    try {
      await navigator.clipboard.writeText(url);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = url;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
    }
    showToast("Link copied to clipboard");
  }

  function toggleSubscribe() {
    setSubscribed((s) => {
      const next = !s;
      try {
        localStorage.setItem(`mytube:subscribed:${video.channelName}`, next ? "1" : "0");
      } catch {}
      return next;
    });
  }

  return (
    <div className="relative">
      <PreRollPlayer src={video.src} poster={video.poster} onFirstPlay={handleFirstPlay} ad={ad} />

      <h1 className="mt-4 text-lg font-bold leading-7 text-yt-text sm:text-xl">{video.title}</h1>

      <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-3">
        <div className="flex items-center gap-3">
          <ChannelAvatar name={video.channelName} image={video.channelImage} size={40} />
          <div>
            <p className="flex items-center gap-1 text-[15px] font-medium text-yt-text">
              {video.channelName}
              <BadgeCheck className="h-4 w-4 fill-yt-sub text-yt-bg" />
            </p>
            <p className="text-xs text-yt-sub">Public creator channel</p>
          </div>
          <button
            onClick={toggleSubscribe}
            className={`ml-2 flex h-9 items-center gap-1.5 rounded-full px-4 text-sm font-medium transition-all hover:scale-[1.03] active:scale-95 ${
              subscribed ? "bg-yt-chip text-yt-text hover:bg-yt-chip-hover" : "bg-white text-black"
            }`}
          >
            {subscribed ? (
              <>
                <Bell className="h-4 w-4" /> Subscribed
              </>
            ) : (
              "Subscribe"
            )}
          </button>
        </div>

        <div className="ml-auto flex flex-wrap items-center gap-2">
          <div className="flex h-9 items-center overflow-hidden rounded-full bg-yt-chip">
            <button
              onClick={() => toggleReaction("like")}
              className={`flex h-full items-center gap-2 pl-4 pr-3 text-sm font-medium transition-colors hover:bg-yt-chip-hover ${
                reaction === "like" ? "text-white" : "text-yt-text"
              }`}
            >
              <ThumbsUp className={`h-[18px] w-[18px] ${reaction === "like" ? "fill-white" : ""}`} />
              {fmtViewsLocal(likes)}
            </button>
            <span className="h-5 w-px bg-white/15" />
            <button
              onClick={() => toggleReaction("dislike")}
              className="flex h-full items-center px-3 transition-colors hover:bg-yt-chip-hover"
            >
              <ThumbsDown
                className={`h-[18px] w-[18px] ${reaction === "dislike" ? "fill-white" : ""}`}
              />
            </button>
          </div>

          <button
            onClick={share}
            className="flex h-9 items-center gap-2 rounded-full bg-yt-chip px-4 text-sm font-medium text-yt-text transition-colors hover:bg-yt-chip-hover"
          >
            <Share2 className="h-[18px] w-[18px]" /> Share
          </button>

          <a
            href={video.src}
            download
            className="hidden h-9 items-center gap-2 rounded-full bg-yt-chip px-4 text-sm font-medium text-yt-text transition-colors hover:bg-yt-chip-hover sm:flex"
          >
            <Download className="h-[18px] w-[18px]" /> Download
          </a>

          {canManage && (
            <Link
              href="/admin"
              className="flex h-9 items-center gap-2 rounded-full border border-yt-border px-4 text-sm font-medium text-yt-sub transition-colors hover:bg-yt-chip hover:text-yt-text"
            >
              <FilePenLine className="h-[18px] w-[18px]" /> Studio
            </Link>
          )}
        </div>
      </div>

      <div className="mt-4 rounded-xl bg-yt-chip p-3 text-sm leading-6 text-yt-text">
        <p className="font-medium">
          {fmtViewsLocal(views)} views • {video.dateLabel} •{" "}
          <Link href={`/?category=${encodeURIComponent(video.category)}`} className="text-yt-blue hover:underline">
            #{video.category}
          </Link>
        </p>
        <div className={`mt-1 whitespace-pre-line text-yt-text/95 ${expanded ? "" : "line-clamp-2"}`}>
          {video.description || "Is video ke liye koi description nahi hai."}
        </div>
        <button
          onClick={() => setExpanded((e) => !e)}
          className="mt-1 font-medium text-yt-sub transition-colors hover:text-yt-text"
        >
          {expanded ? "Show less" : "...more"}
        </button>
      </div>

      <Comments videoId={video.id} initial={[...initialComments.map((c) => ({ ...c }))]} />

      {toast && (
        <div className="fixed bottom-6 left-1/2 z-[70] -translate-x-1/2 animate-pop-in rounded-lg bg-white px-4 py-2.5 text-sm font-medium text-black shadow-2xl">
          <span className="flex items-center gap-2">
            <Check className="h-4 w-4" />
            {toast}
          </span>
        </div>
      )}
    </div>
  );
}
