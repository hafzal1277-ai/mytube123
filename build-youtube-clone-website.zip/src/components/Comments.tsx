"use client";

import { useEffect, useState } from "react";
import { Send, User } from "lucide-react";

export type SerializedComment = {
  id: string;
  author: string;
  content: string;
  when: string;
};

const AVATAR_COLORS = [
  "from-rose-500 to-orange-400",
  "from-violet-500 to-fuchsia-400",
  "from-sky-500 to-cyan-400",
  "from-emerald-500 to-lime-400",
  "from-amber-500 to-yellow-400",
  "from-indigo-500 to-blue-400",
];

function avatarClass(name: string) {
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash += name.charCodeAt(i);
  return AVATAR_COLORS[hash % AVATAR_COLORS.length];
}

export default function Comments({
  videoId,
  initial,
}: {
  videoId: string;
  initial: SerializedComment[];
}) {
  const [list, setList] = useState<SerializedComment[]>(initial);
  const [name, setName] = useState("");
  const [content, setContent] = useState("");
  const [focused, setFocused] = useState(false);
  const [posting, setPosting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    try {
      const saved = localStorage.getItem("mytube:commentName");
      if (saved) setName(saved);
    } catch {}
  }, []);

  async function submit() {
    const text = content.trim();
    if (!text || posting) return;
    setPosting(true);
    setError(null);
    try {
      const res = await fetch("/api/comments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ videoId, author: name.trim(), content: text }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed");
      try {
        if (name.trim()) localStorage.setItem("mytube:commentName", name.trim());
      } catch {}
      setList((l) => [
        {
          id: data.comment.id,
          author: data.comment.author,
          content: data.comment.content,
          when: "just now",
        },
        ...l,
      ]);
      setContent("");
      setFocused(false);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Comment post nahi hua");
    } finally {
      setPosting(false);
    }
  }

  return (
    <section className="mt-8">
      <h2 className="text-base font-bold text-yt-text">
        {list.length} Comments
      </h2>

      {/* input */}
      <div className="mt-5 flex gap-3">
        <span
          className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-gradient-to-br text-sm font-bold text-white ${
            name.trim()
              ? avatarClass(name.trim())
              : "from-neutral-600 to-neutral-500"
          }`}
        >
          {name.trim() ? (
            name.trim()[0]!.toUpperCase()
          ) : (
            <User className="h-4 w-4" />
          )}
        </span>
        <div className="min-w-0 flex-1">
          <input
            value={name}
            onChange={(e) => setName(e.target.value.slice(0, 50))}
            placeholder="Aapka naam (optional)"
            className="w-full border-b border-yt-chip bg-transparent pb-1.5 text-sm text-yt-text outline-none placeholder:text-yt-sub focus:border-white/70"
          />
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value.slice(0, 1000))}
            onFocus={() => setFocused(true)}
            placeholder="Add a comment..."
            rows={focused || content ? 2 : 1}
            className="mt-3 w-full resize-none border-b border-yt-chip bg-transparent pb-1.5 text-sm text-yt-text outline-none placeholder:text-yt-sub focus:border-white/70"
          />
          {error && <p className="mt-2 text-xs text-yt-red">{error}</p>}
          {(focused || content) && (
            <div className="mt-2 flex justify-end gap-2">
              <button
                onClick={() => {
                  setContent("");
                  setFocused(false);
                  setError(null);
                }}
                className="h-9 rounded-full px-4 text-sm font-medium text-yt-text transition-colors hover:bg-yt-chip"
              >
                Cancel
              </button>
              <button
                onClick={submit}
                disabled={!content.trim() || posting}
                className={`flex h-9 items-center gap-1.5 rounded-full px-4 text-sm font-medium transition-colors ${
                  content.trim()
                    ? "bg-yt-blue text-black hover:bg-[#65b8ff]"
                    : "cursor-not-allowed bg-yt-chip text-yt-sub"
                }`}
              >
                <Send className="h-3.5 w-3.5" />
                {posting ? "Posting..." : "Comment"}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* list */}
      <ul className="mt-8 flex flex-col gap-5">
        {list.length === 0 && (
          <li className="rounded-xl border border-dashed border-yt-chip p-8 text-center text-sm text-yt-sub">
            Abhi tak koi comment nahi — pehla comment aap karein!
          </li>
        )}
        {list.map((c) => (
          <li key={c.id} className="flex gap-3">
            <span
              className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-gradient-to-br text-sm font-bold text-white ${avatarClass(
                c.author
              )}`}
            >
              {c.author[0]?.toUpperCase() || "G"}
            </span>
            <div className="min-w-0">
              <p className="text-[13px] text-yt-text">
                <span className="font-medium">
                  @{c.author.replace(/\s+/g, "").toLowerCase() || "guest"}
                </span>{" "}
                <span className="ml-1 text-xs text-yt-sub">{c.when}</span>
              </p>
              <p className="mt-1 whitespace-pre-line text-sm leading-5 text-yt-text">
                {c.content}
              </p>
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}
