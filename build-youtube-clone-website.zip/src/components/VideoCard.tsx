import Link from "next/link";
import { BadgeCheck, Play } from "lucide-react";
import { DEFAULT_CHANNEL_NAME } from "@/lib/constants";

export type CardVideo = {
  id: string;
  title: string;
  thumbnail: string | null;
  durationLabel: string;
  metaLine: string;
  channelName: string;
  channelImage: string | null;
};

export function ChannelAvatar({
  name,
  image,
  size = 36,
}: {
  name: string;
  image?: string | null;
  size?: number;
}) {
  const label = (name || DEFAULT_CHANNEL_NAME).trim();

  if (image) {
    return (
      // eslint-disable-next-line @next/next/no-img-element
      <img
        src={image}
        alt={label}
        className="shrink-0 rounded-full object-cover"
        style={{ width: size, height: size }}
      />
    );
  }

  return (
    <span
      className="flex shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-yt-red to-[#8b5cf6] font-bold text-white"
      style={{ width: size, height: size, fontSize: size * 0.42 }}
    >
      {label[0]?.toUpperCase() || "C"}
    </span>
  );
}

function Thumb({
  video,
  rounded = "rounded-xl",
}: {
  video: CardVideo;
  rounded?: string;
}) {
  return (
    <div className={`relative aspect-video w-full overflow-hidden ${rounded} bg-yt-chip`}>
      {video.thumbnail ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={video.thumbnail}
          alt={video.title}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-300 ease-out group-hover:scale-[1.03]"
        />
      ) : (
        <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-[#1a1a2e] via-[#16213e] to-[#0f3460]">
          <span className="flex h-12 w-12 items-center justify-center rounded-full bg-white/10 backdrop-blur">
            <Play className="h-6 w-6 fill-white text-white" />
          </span>
        </div>
      )}
      <span className="absolute bottom-1.5 right-1.5 rounded bg-black/80 px-1.5 py-0.5 text-[11px] font-medium text-white">
        {video.durationLabel}
      </span>
    </div>
  );
}

export default function VideoCard({ video }: { video: CardVideo }) {
  return (
    <Link href={`/watch?v=${video.id}`} className="group flex flex-col gap-3 outline-none">
      <Thumb video={video} />
      <div className="flex min-w-0 gap-3 pr-2">
        <ChannelAvatar name={video.channelName} image={video.channelImage} />
        <div className="min-w-0">
          <h3 className="line-clamp-2 text-[15px] font-medium leading-[22px] text-yt-text">
            {video.title}
          </h3>
          <div className="mt-1 flex items-center gap-1 text-[13px] text-yt-sub transition-colors hover:text-yt-text">
            {video.channelName}
            <BadgeCheck className="h-3.5 w-3.5 fill-yt-sub text-yt-bg" />
          </div>
          <div className="text-[13px] text-yt-sub">{video.metaLine}</div>
        </div>
      </div>
    </Link>
  );
}

export function VideoRowCard({ video }: { video: CardVideo }) {
  return (
    <Link href={`/watch?v=${video.id}`} className="group flex gap-2 outline-none">
      <div className="w-[168px] shrink-0 sm:w-[168px]">
        <Thumb video={video} rounded="rounded-lg" />
      </div>
      <div className="min-w-0 flex-1">
        <h3 className="line-clamp-2 text-sm font-medium leading-5 text-yt-text">
          {video.title}
        </h3>
        <div className="mt-1 flex items-center gap-1 text-xs text-yt-sub">
          {video.channelName}
          <BadgeCheck className="h-3 w-3 fill-yt-sub text-yt-bg" />
        </div>
        <div className="text-xs text-yt-sub">{video.metaLine}</div>
      </div>
    </Link>
  );
}
