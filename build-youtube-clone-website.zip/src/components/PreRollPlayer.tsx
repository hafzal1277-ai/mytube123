"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { ExternalLink, Info, Volume2, X } from "lucide-react";
import VideoPlayer from "./VideoPlayer";
import type { PreRollConfig } from "@/lib/ads";

function fmt(s: number) {
  return `${Math.max(0, Math.ceil(s))}s`;
}

export default function PreRollPlayer({
  src,
  poster,
  onFirstPlay,
  ad,
}: {
  src: string;
  poster: string | null;
  onFirstPlay?: () => void;
  ad: PreRollConfig;
}) {
  const [stage, setStage] = useState<"ad" | "content">(
    ad.enabled ? "ad" : "content"
  );
  const [remaining, setRemaining] = useState(ad.skipAfterSeconds);
  const adVideoRef = useRef<HTMLVideoElement>(null);

  const canSkip = remaining <= 0;
  const showAd = ad.enabled && stage === "ad";

  useEffect(() => {
    setStage(ad.enabled ? "ad" : "content");
    setRemaining(ad.skipAfterSeconds);
  }, [ad.enabled, ad.skipAfterSeconds, src]);

  useEffect(() => {
    if (!showAd) return;
    const timer = setInterval(() => {
      setRemaining((r) => (r <= 1 ? 0 : r - 1));
    }, 1000);
    return () => clearInterval(timer);
  }, [showAd]);

  useEffect(() => {
    if (!showAd) return;
    if (ad.mode === "iframe" || ad.mode === "image" || ad.mode === "link" || ad.mode === "html") {
      const t = setTimeout(() => setStage("content"), ad.totalSeconds * 1000);
      return () => clearTimeout(t);
    }
  }, [showAd, ad.mode, ad.totalSeconds]);

  useEffect(() => {
    if (showAd && ad.mode === "video") {
      adVideoRef.current?.play().catch(() => {});
    }
  }, [showAd, ad.mode]);

  const sponsorHref = useMemo(() => ad.clickUrl || "#", [ad.clickUrl]);

  if (!showAd) {
    return <VideoPlayer src={src} poster={poster} onFirstPlay={onFirstPlay} />;
  }

  return (
    <div className="relative aspect-video w-full overflow-hidden bg-black sm:rounded-xl">
      {ad.mode === "video" && ad.videoUrl ? (
        <video
          ref={adVideoRef}
          src={ad.videoUrl}
          autoPlay
          playsInline
          muted
          className="h-full w-full object-cover"
          onEnded={() => setStage("content")}
        />
      ) : ad.mode === "iframe" && ad.iframeUrl ? (
        <iframe
          src={ad.iframeUrl}
          title={ad.title}
          className="h-full w-full border-0"
          allow="autoplay; fullscreen; clipboard-write"
        />
      ) : ad.mode === "image" && ad.imageUrl ? (
        <a
          href={sponsorHref}
          target="_blank"
          rel="noreferrer sponsored"
          className="block h-full w-full"
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={ad.imageUrl}
            alt={ad.title}
            className="h-full w-full object-cover"
          />
        </a>
      ) : ad.mode === "html" && ad.htmlCode ? (
        <iframe
          title={ad.title}
          srcDoc={ad.htmlCode}
          className="h-full w-full border-0 bg-white"
          sandbox="allow-scripts allow-popups allow-popups-to-escape-sandbox allow-forms allow-modals allow-downloads"
          referrerPolicy="no-referrer"
        />
      ) : (
        <a
          href={sponsorHref}
          target="_blank"
          rel="noreferrer sponsored"
          className="flex h-full w-full items-center justify-center bg-[radial-gradient(circle_at_top,#1f2937,transparent_55%),linear-gradient(135deg,#111827,#030712)] p-6 text-center"
        >
          <div>
            <p className="text-xs uppercase tracking-[0.3em] text-white/60">
              Sponsored
            </p>
            <h3 className="mt-3 text-2xl font-bold text-white">{ad.brand}</h3>
            <p className="mt-2 max-w-xl text-sm leading-6 text-white/75">
              {ad.title}
            </p>
            <span className="mt-6 inline-flex h-11 items-center gap-2 rounded-full bg-white px-5 text-sm font-bold text-black">
              Open sponsor <ExternalLink className="h-4 w-4" />
            </span>
          </div>
        </a>
      )}

      <div className="absolute inset-x-0 top-0 flex items-center justify-between bg-gradient-to-b from-black/85 to-transparent p-3 text-white">
        <div className="rounded-full bg-black/45 px-3 py-1 text-xs font-medium backdrop-blur-sm">
          Ad · {ad.brand}
        </div>
        <div className="flex items-center gap-2">
          {ad.mode === "video" && (
            <div className="hidden items-center gap-2 rounded-full bg-black/45 px-3 py-1 text-xs backdrop-blur-sm sm:flex">
              <Volume2 className="h-3.5 w-3.5" />
              Video ad
            </div>
          )}
          <button
            onClick={() => setStage("content")}
            className="flex h-9 items-center gap-1.5 rounded-full bg-black/50 px-3 text-xs font-medium text-white backdrop-blur-sm transition-colors hover:bg-black/70"
          >
            <X className="h-3.5 w-3.5" />
            Close ad
          </button>
        </div>
      </div>

      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 to-transparent p-4">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-sm font-medium text-white">{ad.title}</p>
            <p className="mt-1 flex items-center gap-1.5 text-xs text-white/70">
              <Info className="h-3.5 w-3.5" />
              Skip after {fmt(remaining)}
            </p>
          </div>
          <div className="flex items-center gap-2">
            {ad.clickUrl && (
              <a
                href={ad.clickUrl}
                target="_blank"
                rel="noreferrer sponsored"
                className="flex h-10 items-center gap-2 rounded-full bg-white px-4 text-sm font-bold text-black transition-transform hover:scale-[1.03]"
              >
                Visit sponsor
                <ExternalLink className="h-4 w-4" />
              </a>
            )}
            <button
              onClick={() => canSkip && setStage("content")}
              disabled={!canSkip}
              className={`h-10 rounded-full px-4 text-sm font-bold transition-colors ${
                canSkip
                  ? "bg-yt-red text-white hover:bg-[#e6002e]"
                  : "cursor-not-allowed bg-white/15 text-white/60"
              }`}
            >
              {canSkip ? "Skip ad" : `Skip in ${fmt(remaining)}`}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
