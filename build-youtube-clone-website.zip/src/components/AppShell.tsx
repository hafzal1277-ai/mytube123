"use client";

import { useState, type ReactNode } from "react";
import Link from "next/link";
import { usePathname, useSearchParams } from "next/navigation";
import {
  Menu,
  Search,
  Mic,
  Video,
  Bell,
  User,
  Home,
  Flame,
  Users,
  History,
  Clock,
  ThumbsUp,
  LogIn,
  LogOut,
  LayoutDashboard,
  Upload,
  ArrowLeft,
  LayoutGrid,
  Music,
  Gamepad2,
  GraduationCap,
  Cpu,
  Laugh,
  Trophy,
  Plane,
  Newspaper,
  Clapperboard,
  UtensilsCrossed,
  type LucideIcon,
} from "lucide-react";
import Logo from "./Logo";
import { CATEGORIES } from "@/lib/constants";
import { ChannelAvatar } from "./VideoCard";

const CATEGORY_ICONS: Record<string, LucideIcon> = {
  General: LayoutGrid,
  Vlogs: Video,
  Music,
  Gaming: Gamepad2,
  Education: GraduationCap,
  Tech: Cpu,
  Comedy: Laugh,
  Sports: Trophy,
  Travel: Plane,
  News: Newspaper,
  Film: Clapperboard,
  Food: UtensilsCrossed,
};

function NavLink({
  href,
  icon: Icon,
  label,
  active,
  onClick,
}: {
  href: string;
  icon: LucideIcon;
  label: string;
  active: boolean;
  onClick?: () => void;
}) {
  return (
    <Link
      href={href}
      onClick={onClick}
      className={`flex items-center gap-6 rounded-lg px-3 py-2 text-sm transition-colors ${
        active
          ? "bg-yt-chip font-medium text-yt-text"
          : "text-yt-text/90 hover:bg-[#272727]"
      }`}
    >
      <Icon className="h-5 w-5 shrink-0" strokeWidth={active ? 2.2 : 1.8} />
      <span className="truncate">{label}</span>
    </Link>
  );
}

function StaticItem({ icon: Icon, label }: { icon: LucideIcon; label: string }) {
  return (
    <div className="flex cursor-pointer items-center gap-6 rounded-lg px-3 py-2 text-sm text-yt-text/90 transition-colors hover:bg-[#272727]">
      <Icon className="h-5 w-5 shrink-0" strokeWidth={1.8} />
      <span className="truncate">{label}</span>
    </div>
  );
}

export default function AppShell({
  viewer,
  children,
}: {
  viewer:
    | {
        authProvider: "google" | "admin";
        id: string | null;
        name: string;
        email: string | null;
        image: string | null;
        isAdmin: boolean;
      }
    | null;
  children: ReactNode;
}) {
  const [open, setOpen] = useState(true);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [mobileSearch, setMobileSearch] = useState(false);
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const q = searchParams.get("q") || "";
  const currentCategory = searchParams.get("category");
  const currentSort = searchParams.get("sort");

  function toggleMenu() {
    if (window.matchMedia("(min-width: 1024px)").matches) {
      setOpen((o) => !o);
    } else {
      setDrawerOpen(true);
    }
  }

  function isActive(href: string) {
    if (href.startsWith("/?")) {
      const params = new URLSearchParams(href.slice(2));
      if (pathname !== "/") return false;
      for (const [k, v] of params) {
        if (searchParams.get(k) !== v) return false;
      }
      return true;
    }
    return pathname === href;
  }

  async function handleLogout() {
    if (!viewer) return;
    if (viewer.authProvider === "google") {
      // Dynamically import to avoid SSR issues
      const { signOut } = await import("next-auth/react");
      await signOut({ callbackUrl: "/" });
      return;
    }
    await fetch("/api/auth/logout", {
      method: "POST",
      credentials: "same-origin",
    });
    window.location.href = "/";
  }

  const sidebarContent = (onNavigate?: () => void) => (
    <nav className="flex flex-col gap-0.5 px-3 pb-8">
      <NavLink
        href="/"
        icon={Home}
        label="Home"
        active={pathname === "/" && !currentCategory && !currentSort && !q}
        onClick={onNavigate}
      />
      <NavLink
        href="/?sort=popular"
        icon={Flame}
        label="Trending"
        active={isActive("/?sort=popular")}
        onClick={onNavigate}
      />
      <StaticItem icon={Users} label="Subscriptions" />
      <div className="my-2 border-t border-yt-chip" />
      <div className="px-3 py-1.5 text-[15px] font-medium text-yt-text">You</div>
      <StaticItem icon={History} label="History" />
      <StaticItem icon={Clock} label="Watch later" />
      <StaticItem icon={ThumbsUp} label="Liked videos" />
      <div className="my-2 border-t border-yt-chip" />
      <div className="px-3 py-1.5 text-[15px] font-medium text-yt-text">
        Categories
      </div>
      {CATEGORIES.map((c) => (
        <NavLink
          key={c}
          href={`/?category=${encodeURIComponent(c)}`}
          icon={CATEGORY_ICONS[c] || LayoutGrid}
          label={c}
          active={isActive(`/?category=${encodeURIComponent(c)}`)}
          onClick={onNavigate}
        />
      ))}
      <div className="my-2 border-t border-yt-chip" />
      <div className="px-3 py-1.5 text-[15px] font-medium text-yt-text">Studio</div>
      {viewer ? (
        <>
          <NavLink
            href="/admin"
            icon={LayoutDashboard}
            label="Your studio"
            active={pathname === "/admin"}
            onClick={onNavigate}
          />
          <NavLink
            href="/admin/upload"
            icon={Upload}
            label="Upload video"
            active={pathname === "/admin/upload"}
            onClick={onNavigate}
          />
          <button
            onClick={() => {
              onNavigate?.();
              void handleLogout();
            }}
            className="flex items-center gap-6 rounded-lg px-3 py-2 text-left text-sm text-yt-text/90 transition-colors hover:bg-[#272727]"
          >
            <LogOut className="h-5 w-5 shrink-0" strokeWidth={1.8} />
            Sign out
          </button>
        </>
      ) : (
        <NavLink
          href="/admin/login"
          icon={LogIn}
          label="Sign in / Google"
          active={pathname === "/admin/login"}
          onClick={onNavigate}
        />
      )}
      <p className="mt-6 px-3 text-xs leading-5 text-yt-sub">
        MyTube — multi-creator video platform.
        <br />© {new Date().getFullYear()} MyTube
      </p>
    </nav>
  );

  return (
    <div className="min-h-screen bg-yt-bg">
      <header className="fixed inset-x-0 top-0 z-50 bg-[#0f0f0f]/95 backdrop-blur">
        <div className="flex h-14 items-center gap-2 px-2 sm:gap-4 sm:px-4">
          {mobileSearch ? (
            <div className="flex w-full items-center gap-2 md:hidden">
              <button
                onClick={() => setMobileSearch(false)}
                className="rounded-full p-2 transition-colors hover:bg-yt-chip"
                aria-label="Back"
              >
                <ArrowLeft className="h-5 w-5" />
              </button>
              <form action="/" className="flex flex-1">
                <input
                  name="q"
                  defaultValue={q}
                  autoFocus
                  placeholder="Search"
                  className="h-10 w-full rounded-l-full border border-yt-border bg-[#121212] px-4 text-sm text-yt-text outline-none placeholder:text-yt-sub focus:border-[#1c62b9]"
                />
                <button
                  type="submit"
                  className="flex h-10 w-14 items-center justify-center rounded-r-full border border-l-0 border-yt-border bg-yt-chip transition-colors hover:bg-yt-chip-hover"
                >
                  <Search className="h-5 w-5" />
                </button>
              </form>
            </div>
          ) : (
            <>
              <div className="flex items-center">
                <button
                  onClick={toggleMenu}
                  className="rounded-full p-2 transition-colors hover:bg-yt-chip"
                  aria-label="Menu"
                >
                  <Menu className="h-5 w-5" />
                </button>
                <Logo />
              </div>

              <form action="/" className="hidden min-w-0 flex-1 justify-center md:flex">
                <div className="flex w-full max-w-[720px] items-center">
                  <input
                    name="q"
                    defaultValue={q}
                    placeholder="Search"
                    className="h-10 w-full min-w-0 rounded-l-full border border-yt-border bg-[#121212] px-4 text-[15px] text-yt-text outline-none placeholder:text-yt-sub focus:border-[#1c62b9]"
                  />
                  <button
                    type="submit"
                    className="flex h-10 w-16 shrink-0 items-center justify-center rounded-r-full border border-l border-yt-border bg-[#222222] transition-colors hover:bg-yt-chip-hover"
                  >
                    <Search className="h-5 w-5" />
                  </button>
                  <button
                    type="button"
                    className="ml-3 hidden h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#181818] transition-colors hover:bg-yt-chip lg:flex"
                    title="Search with voice"
                  >
                    <Mic className="h-5 w-5" />
                  </button>
                </div>
              </form>

              <div className="ml-auto flex items-center gap-1 sm:gap-2">
                <button
                  onClick={() => setMobileSearch(true)}
                  className="rounded-full p-2 transition-colors hover:bg-yt-chip md:hidden"
                >
                  <Search className="h-5 w-5" />
                </button>
                {viewer ? (
                  <>
                    <Link
                      href="/admin/upload"
                      title="Upload video"
                      className="flex h-10 items-center gap-2 rounded-full px-3 transition-colors hover:bg-yt-chip"
                    >
                      <Video className="h-5 w-5" />
                      <span className="hidden text-sm font-medium xl:inline">Create</span>
                    </Link>
                    <button
                      title="Notifications"
                      className="relative rounded-full p-2 transition-colors hover:bg-yt-chip"
                    >
                      <Bell className="h-5 w-5" />
                      <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-yt-red" />
                    </button>
                    <Link href="/admin" title="Your Studio">
                      <ChannelAvatar
                        name={viewer.name}
                        image={viewer.image}
                        size={32}
                      />
                    </Link>
                  </>
                ) : (
                  <Link
                    href="/admin/login"
                    className="ml-1 flex h-9 items-center gap-2 rounded-full border border-yt-border px-4 text-sm font-medium text-yt-blue transition-colors hover:bg-[#263850]"
                  >
                    <User className="h-5 w-5" />
                    Sign in
                  </Link>
                )}
              </div>
            </>
          )}
        </div>
      </header>

      <aside
        className={`yt-scroll fixed bottom-0 left-0 top-14 hidden overflow-y-auto overflow-x-hidden pb-4 pt-2 transition-[width] duration-200 lg:block ${
          open ? "w-60" : "w-[72px]"
        }`}
      >
        {open ? (
          sidebarContent()
        ) : (
          <div className="flex flex-col items-center gap-1 pt-1">
            {[
              { href: "/", icon: Home, label: "Home" },
              { href: "/?sort=popular", icon: Flame, label: "Trending" },
              { href: "/?category=Vlogs", icon: Users, label: "Subs" },
              { href: "/?category=Music", icon: Music, label: "Music" },
            ].map((i) => (
              <Link
                key={i.label}
                href={i.href}
                className="flex w-16 flex-col items-center gap-1.5 rounded-lg py-3.5 text-yt-text/90 transition-colors hover:bg-[#272727]"
              >
                <i.icon className="h-5 w-5" strokeWidth={1.8} />
                <span className="text-[10px]">{i.label}</span>
              </Link>
            ))}
          </div>
        )}
      </aside>

      {drawerOpen && (
        <div className="fixed inset-0 z-[60] lg:hidden">
          <div className="absolute inset-0 bg-black/60" onClick={() => setDrawerOpen(false)} />
          <aside className="yt-scroll absolute bottom-0 left-0 top-0 w-64 animate-pop-in overflow-y-auto bg-yt-bg">
            <div className="flex h-14 items-center px-4">
              <button
                onClick={() => setDrawerOpen(false)}
                className="rounded-full p-2 transition-colors hover:bg-yt-chip"
              >
                <Menu className="h-5 w-5" />
              </button>
              <Logo />
            </div>
            {sidebarContent(() => setDrawerOpen(false))}
          </aside>
        </div>
      )}

      <main className={`pt-14 transition-[padding] duration-200 ${open ? "lg:pl-60" : "lg:pl-[72px]"}`}>
        {children}
      </main>
    </div>
  );
}
