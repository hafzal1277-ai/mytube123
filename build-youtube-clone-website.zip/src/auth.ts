import NextAuth from "next-auth";
import Google from "next-auth/providers/google";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { creatorUsers } from "@/db/schema";
import { ensureAppReady } from "@/lib/bootstrap";

const googleEnabled = Boolean(
  process.env.AUTH_GOOGLE_ID && process.env.AUTH_GOOGLE_SECRET
);

async function upsertGoogleUser(input: {
  googleId?: string | null;
  email: string;
  name: string;
  image?: string | null;
}) {
  await ensureAppReady();
  const [existing] = await db
    .select()
    .from(creatorUsers)
    .where(eq(creatorUsers.email, input.email))
    .limit(1);

  if (existing) {
    const [updated] = await db
      .update(creatorUsers)
      .set({
        googleId: input.googleId ?? existing.googleId,
        name: input.name,
        image: input.image ?? existing.image,
        lastLoginAt: new Date(),
      })
      .where(eq(creatorUsers.id, existing.id))
      .returning();
    return updated;
  }

  const [created] = await db
    .insert(creatorUsers)
    .values({
      googleId: input.googleId ?? null,
      email: input.email,
      name: input.name,
      image: input.image ?? null,
    })
    .returning();
  return created;
}

const providers = googleEnabled
  ? [
      Google({
        clientId: process.env.AUTH_GOOGLE_ID!,
        clientSecret: process.env.AUTH_GOOGLE_SECRET!,
        authorization: {
          params: {
            prompt: "consent",
            access_type: "offline",
            response_type: "code",
            redirect_uri: process.env.AUTH_URL ? `${process.env.AUTH_URL}/api/auth/callback/google` : undefined,
          },
        },
      }),
    ]
  : [];

export const { handlers, auth, signIn, signOut } = NextAuth({
  trustHost: true,
  secret: process.env.AUTH_SECRET || "mytube-auth-secret-local-dev-very-secure-random",
  session: { strategy: "jwt" },
  providers,
  pages: {
    signIn: "/admin/login",
  },
  callbacks: {
    async signIn({ account, profile, user }) {
      if (account?.provider !== "google") return true;

      const email = user.email || (typeof profile?.email === "string" ? profile.email : "");
      if (!email) return false;

      if (
        typeof (profile as { email_verified?: unknown } | undefined)?.email_verified ===
          "boolean" &&
        !(profile as { email_verified?: boolean }).email_verified
      ) {
        return false;
      }

      await upsertGoogleUser({
        googleId: account.providerAccountId,
        email,
        name: user.name || email.split("@")[0] || "Creator",
        image: user.image,
      });
      return true;
    },
    async jwt({ token, user }) {
      const email = user?.email || token.email;
      if (email && (!token.userId || user)) {
        await ensureAppReady();
        const [dbUser] = await db
          .select()
          .from(creatorUsers)
          .where(eq(creatorUsers.email, email))
          .limit(1);
        if (dbUser) {
          token.userId = dbUser.id;
          token.name = dbUser.name;
          token.email = dbUser.email;
          token.picture = dbUser.image ?? undefined;
        }
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        if (token.userId) session.user.id = token.userId;
        session.user.name = (token.name as string | undefined) ?? session.user.name;
        session.user.email = (token.email as string | undefined) ?? session.user.email;
        session.user.image = (token.picture as string | undefined) ?? session.user.image;
      }
      return session;
    },
  },
});

export { googleEnabled };
