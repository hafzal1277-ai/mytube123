import "server-only";

import { pool } from "@/db";

const SAMPLE_VIDEOS = [
  {
    id: "0f5a1b2c-3d4e-4f50-8091-a2b3c4d5e6f1",
    uploaderName: "Featured Creator",
    title: "Big Buck Bunny — Animated Short Film",
    description:
      "A giant gentle rabbit wakes up in a beautiful meadow. Classic animated short.",
    category: "Film",
    videoPath: "/api/media/videos/0f5a1b2c-3d4e-4f50-8091-a2b3c4d5e6f1.mp4",
    thumbnailPath:
      "/api/media/thumbnails/0f5a1b2c-3d4e-4f50-8091-a2b3c4d5e6f1.jpg",
    durationSeconds: 10,
    views: 148230,
    likes: 12930,
    dislikes: 214,
    createdAgo: "12 days",
  },
  {
    id: "0f5a1b2c-3d4e-4f50-8091-a2b3c4d5e6f2",
    uploaderName: "Featured Creator",
    title: "Sintel — Epic Fantasy Journey",
    description: "A lonely warrior searches for her dragon friend.",
    category: "Film",
    videoPath: "/api/media/videos/0f5a1b2c-3d4e-4f50-8091-a2b3c4d5e6f2.mp4",
    thumbnailPath:
      "/api/media/thumbnails/0f5a1b2c-3d4e-4f50-8091-a2b3c4d5e6f2.jpg",
    durationSeconds: 10,
    views: 96412,
    likes: 8420,
    dislikes: 101,
    createdAgo: "7 days",
  },
  {
    id: "0f5a1b2c-3d4e-4f50-8091-a2b3c4d5e6f3",
    uploaderName: "Ocean Relax TV",
    title: "Mesmerizing Jellyfish — Deep Ocean 1080p",
    description: "Relaxing jellyfish footage. Headphones on, full volume!",
    category: "Travel",
    videoPath: "/api/media/videos/0f5a1b2c-3d4e-4f50-8091-a2b3c4d5e6f3.mp4",
    thumbnailPath:
      "/api/media/thumbnails/0f5a1b2c-3d4e-4f50-8091-a2b3c4d5e6f3.jpg",
    durationSeconds: 10,
    views: 231804,
    likes: 21033,
    dislikes: 305,
    createdAgo: "3 days",
  },
  {
    id: "0f5a1b2c-3d4e-4f50-8091-a2b3c4d5e6f4",
    uploaderName: "Nature Lens",
    title: "Flower Bloom Macro — Nature Close-Up",
    description: "Extreme close-up of a blooming flower with dew drops.",
    category: "Vlogs",
    videoPath: "/api/media/videos/0f5a1b2c-3d4e-4f50-8091-a2b3c4d5e6f4.mp4",
    thumbnailPath:
      "/api/media/thumbnails/0f5a1b2c-3d4e-4f50-8091-a2b3c4d5e6f4.jpg",
    durationSeconds: 6,
    views: 58310,
    likes: 4912,
    dislikes: 44,
    createdAgo: "16 hours",
  },
] as const;

const SAMPLE_COMMENTS = [
  [
    "0f5a1b2c-3d4e-4f50-8091-a2b3c4d5e6f3",
    "Ayesha Khan",
    "Kitna relaxing hai! Roz raat ko yeh dekhti hoon.",
    "2 days",
  ],
  [
    "0f5a1b2c-3d4e-4f50-8091-a2b3c4d5e6f3",
    "Bilal Ahmed",
    "Zabardast! Great upload.",
    "1 day",
  ],
  [
    "0f5a1b2c-3d4e-4f50-8091-a2b3c4d5e6f1",
    "Hamza",
    "Childhood favorite!",
    "10 days",
  ],
  [
    "0f5a1b2c-3d4e-4f50-8091-a2b3c4d5e6f2",
    "Sara Malik",
    "The soundtrack is unreal.",
    "5 days",
  ],
] as const;

export async function ensureAppReady() {
  await pool.query(`CREATE EXTENSION IF NOT EXISTS pgcrypto;`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS admin_users (
      id serial PRIMARY KEY,
      username text NOT NULL UNIQUE,
      password_hash text NOT NULL,
      created_at timestamptz NOT NULL DEFAULT now()
    );

    CREATE TABLE IF NOT EXISTS creator_users (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      google_id text UNIQUE,
      email text NOT NULL UNIQUE,
      name text NOT NULL,
      image text,
      created_at timestamptz NOT NULL DEFAULT now(),
      last_login_at timestamptz NOT NULL DEFAULT now()
    );

    CREATE TABLE IF NOT EXISTS videos (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      uploader_id uuid REFERENCES creator_users(id) ON DELETE SET NULL,
      uploader_name text NOT NULL DEFAULT 'MyTube Creator',
      uploader_image text,
      title text NOT NULL,
      description text NOT NULL DEFAULT '',
      category text NOT NULL DEFAULT 'General',
      video_path text NOT NULL,
      thumbnail_path text,
      ad_title text NOT NULL DEFAULT 'Sponsored',
      ad_html text,
      ad_click_url text,
      ad_skip_after_seconds integer NOT NULL DEFAULT 5,
      duration_seconds integer NOT NULL DEFAULT 0,
      views integer NOT NULL DEFAULT 0,
      likes integer NOT NULL DEFAULT 0,
      dislikes integer NOT NULL DEFAULT 0,
      created_at timestamptz NOT NULL DEFAULT now()
    );

    CREATE TABLE IF NOT EXISTS comments (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      video_id uuid NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
      author text NOT NULL DEFAULT 'Guest',
      content text NOT NULL,
      created_at timestamptz NOT NULL DEFAULT now()
    );
  `);

  const videoCount = await pool.query(`SELECT count(*)::int AS count FROM videos`);
  if (Number(videoCount.rows[0]?.count || 0) > 0) return;

  for (const video of SAMPLE_VIDEOS) {
    await pool.query(
      `INSERT INTO videos (
        id, uploader_name, title, description, category, video_path,
        thumbnail_path, duration_seconds, views, likes, dislikes, created_at
      ) VALUES (
        $1, $2, $3, $4, $5, $6,
        $7, $8, $9, $10, $11, now() - $12::interval
      ) ON CONFLICT (id) DO NOTHING`,
      [
        video.id,
        video.uploaderName,
        video.title,
        video.description,
        video.category,
        video.videoPath,
        video.thumbnailPath,
        video.durationSeconds,
        video.views,
        video.likes,
        video.dislikes,
        video.createdAgo,
      ]
    );
  }

  for (const comment of SAMPLE_COMMENTS) {
    await pool.query(
      `INSERT INTO comments (video_id, author, content, created_at)
       VALUES ($1, $2, $3, now() - $4::interval)`,
      [comment[0], comment[1], comment[2], comment[3]]
    );
  }
}
