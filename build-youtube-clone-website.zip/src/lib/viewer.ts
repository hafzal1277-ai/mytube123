import "server-only";

import { auth, googleEnabled } from "@/auth";
import { getAdminSession } from "@/lib/auth";
import { ensureAppReady } from "@/lib/bootstrap";

export type Viewer = {
  authProvider: "google" | "admin";
  id: string | null;
  name: string;
  email: string | null;
  image: string | null;
  isAdmin: boolean;
};

export async function getViewer(): Promise<Viewer | null> {
  await ensureAppReady();

  const session = await auth();
  if (session?.user?.email) {
    return {
      authProvider: "google",
      id: session.user.id ?? null,
      name: session.user.name || session.user.email.split("@")[0] || "Creator",
      email: session.user.email,
      image: session.user.image ?? null,
      isAdmin: false,
    };
  }

  const admin = await getAdminSession();
  if (admin) {
    return {
      authProvider: "admin",
      id: null,
      name: admin.username,
      email: null,
      image: null,
      isAdmin: true,
    };
  }

  return null;
}

export function isGoogleConfigured() {
  return googleEnabled;
}
