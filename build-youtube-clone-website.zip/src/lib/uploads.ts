import path from "path";
import fs from "fs";

export const UPLOAD_ROOT = path.join(process.cwd(), "public", "uploads");
export const VIDEO_DIR = path.join(UPLOAD_ROOT, "videos");
export const THUMB_DIR = path.join(UPLOAD_ROOT, "thumbnails");

export function ensureUploadDirs() {
  fs.mkdirSync(VIDEO_DIR, { recursive: true });
  fs.mkdirSync(THUMB_DIR, { recursive: true });
}

const VIDEO_EXT: Record<string, string> = {
  "video/mp4": ".mp4",
  "video/webm": ".webm",
  "video/ogg": ".ogv",
  "video/quicktime": ".mov",
  "video/x-matroska": ".mkv",
  "video/x-msvideo": ".avi",
  "video/3gpp": ".3gp",
  "video/mpeg": ".mpeg",
};

const IMAGE_EXT: Record<string, string> = {
  "image/jpeg": ".jpg",
  "image/png": ".png",
  "image/webp": ".webp",
  "image/gif": ".gif",
  "image/avif": ".avif",
};

export function isVideoMime(mime: string): boolean {
  return mime.startsWith("video/");
}

export function isImageMime(mime: string): boolean {
  return mime.startsWith("image/");
}

export function videoExt(mime: string, filename: string): string {
  if (VIDEO_EXT[mime]) return VIDEO_EXT[mime];
  const ext = path.extname(filename || "");
  return ext && ext.length <= 6 ? ext : ".mp4";
}

export function imageExt(mime: string, filename: string): string {
  if (IMAGE_EXT[mime]) return IMAGE_EXT[mime];
  const ext = path.extname(filename || "");
  return ext && ext.length <= 6 ? ext : ".jpg";
}

export function publicPathToDisk(publicPath: string): string {
  // Stored paths look like "/api/media/videos/xxx.mp4" (or legacy "/uploads/videos/xxx.mp4")
  // Both map to files on disk inside public/uploads/
  const rel = publicPath
    .replace(/^\/+/, "")
    .replace(/^api\/media\//, "uploads/");
  return path.join(process.cwd(), "public", rel);
}

export function safeUnlink(publicPath: string | null | undefined) {
  if (!publicPath) return;
  try {
    fs.unlinkSync(publicPathToDisk(publicPath));
  } catch {
    // ignore missing files
  }
}
