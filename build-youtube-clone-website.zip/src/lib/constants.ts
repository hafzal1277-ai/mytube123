export const CATEGORIES = [
  "General",
  "Vlogs",
  "Music",
  "Gaming",
  "Education",
  "Tech",
  "Comedy",
  "Sports",
  "Travel",
  "News",
  "Film",
  "Food",
] as const;

export const SITE_NAME = "MyTube";
export const DEFAULT_CHANNEL_NAME = "MyTube Creator";
