import "server-only";

import { cookies } from "next/headers";
import { SignJWT, jwtVerify } from "jose";
import { randomBytes, scryptSync, timingSafeEqual } from "crypto";
import { db } from "@/db";
import { adminUsers } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { ensureAppReady } from "@/lib/bootstrap";

const COOKIE_NAME = "mytube_session";
const secret = new TextEncoder().encode(
  process.env.SESSION_SECRET || "mytube-dev-session-secret-change-in-production"
);

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const test = scryptSync(password, salt, 64).toString("hex");
  const a = Buffer.from(hash, "hex");
  const b = Buffer.from(test, "hex");
  return a.length === b.length && timingSafeEqual(a, b);
}

export async function ensureAdminSeeded() {
  await ensureAppReady();
  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(adminUsers);
  if (count === 0) {
    await db.insert(adminUsers).values({
      username: process.env.ADMIN_USERNAME || "admin",
      passwordHash: hashPassword(process.env.ADMIN_PASSWORD || "admin123"),
    });
  }
}

export async function verifyAdminCredentials(
  username: string,
  password: string
): Promise<boolean> {
  await ensureAdminSeeded();
  const [user] = await db
    .select()
    .from(adminUsers)
    .where(eq(adminUsers.username, username))
    .limit(1);
  if (!user) return false;
  return verifyPassword(password, user.passwordHash);
}

export async function signAdminSession(username: string): Promise<string> {
  return new SignJWT({ u: username, role: "admin" })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("7d")
    .sign(secret);
}

export async function getAdminSession(): Promise<{ username: string } | null> {
  const store = await cookies();
  const token = store.get(COOKIE_NAME)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret);
    if (payload.role !== "admin" || typeof payload.u !== "string") return null;
    return { username: payload.u };
  } catch {
    return null;
  }
}

export function sessionCookieOptions() {
  return {
    name: COOKIE_NAME,
    httpOnly: true,
    sameSite: "lax" as const,
    secure: false,
    path: "/",
    maxAge: 60 * 60 * 24 * 7,
  };
}
