export type PreRollConfig = {
  enabled: boolean;
  mode: "html" | "video" | "iframe" | "image" | "link";
  title: string;
  brand: string;
  clickUrl: string | null;
  videoUrl: string | null;
  iframeUrl: string | null;
  imageUrl: string | null;
  htmlCode: string | null;
  skipAfterSeconds: number;
  totalSeconds: number;
};

function int(v: string | undefined, fallback: number) {
  const n = Number(v);
  return Number.isFinite(n) && n > 0 ? Math.round(n) : fallback;
}

export function getPreRollConfig(): PreRollConfig {
  const videoUrl = process.env.NEXT_PUBLIC_PREROLL_VIDEO_URL || null;
  const iframeUrl = process.env.NEXT_PUBLIC_PREROLL_IFRAME_URL || null;
  const imageUrl = process.env.NEXT_PUBLIC_PREROLL_IMAGE_URL || null;
  const clickUrl = process.env.NEXT_PUBLIC_PREROLL_CLICK_URL || null;

  const mode = videoUrl
    ? "video"
    : iframeUrl
      ? "iframe"
      : imageUrl
        ? "image"
        : clickUrl
          ? "link"
          : "link";

  const enabled = Boolean(videoUrl || iframeUrl || imageUrl || clickUrl);

  return {
    enabled,
    mode,
    title: process.env.NEXT_PUBLIC_PREROLL_TITLE || "Sponsored message",
    brand: process.env.NEXT_PUBLIC_PREROLL_BRAND || "Adsterra Sponsor",
    clickUrl,
    videoUrl,
    iframeUrl,
    imageUrl,
    htmlCode: null,
    skipAfterSeconds: int(process.env.NEXT_PUBLIC_PREROLL_SKIP_AFTER, 5),
    totalSeconds: int(process.env.NEXT_PUBLIC_PREROLL_DURATION, 8),
  };
}

export function buildVideoPreRoll(input: {
  adTitle: string | null;
  adHtml: string | null;
  adClickUrl: string | null;
  adSkipAfterSeconds: number | null;
}): PreRollConfig | null {
  const htmlCode = input.adHtml?.trim() || null;
  const clickUrl = input.adClickUrl?.trim() || null;
  if (!htmlCode && !clickUrl) return null;

  const skipAfterSeconds = Math.max(1, input.adSkipAfterSeconds || 5);

  return {
    enabled: true,
    mode: htmlCode ? "html" : "link",
    title: input.adTitle?.trim() || "Sponsored",
    brand: "Adsterra Sponsor",
    clickUrl,
    videoUrl: null,
    iframeUrl: null,
    imageUrl: null,
    htmlCode,
    skipAfterSeconds,
    totalSeconds: Math.max(skipAfterSeconds + 10, 15),
  };
}
